# IVY11 GRRM BASE – vollständige Online-Quellenparität (Research, NO PUBLISH)

Stand der Erstellung: 19.10.2026
**Vor dem Test bitte KEINE der bisherigen GPT-Dateien, IVY4-CSV-Workflows oder FAST-Snapshots ändern.**

## Zweck und aktueller Status
- Historischer BASE-V3-Replay: PASS (9.287/9.287, maximale VP-/MSP-Abweichung 4,263e-14).
- GitHub-Verbindungstest vom 19.10.2026: 9/9 offizielle Endpunkte erreichbar.
- Vollständige Online-Quellenparität mit Originaltoleranzen: **noch nicht ausgeführt**.
- Prospektiver BASE-Refresh: **noch nicht ausgeführt**.
- Freigabe / aktueller BASE-Stand: **NO-GO / 02.10.2026**, bis ein echter Quellenlauf besteht.
- HE/HF: exakt historisch nachgebildete Rekonstruktion, KEINE Originaldateien.

## Nur ZWEI neue Dateien in GitHub hochladen
Die ZIP enthält:
1. `base-parity-research-bundle.zip` – auf GitHub in das HAUPTVERZEICHNIS (Root), NICHT entpacken.
2. `.github/workflows/ivy11-base-v3-online-paritaet-readonly.yml` – GitHub-Pfad `.github/workflows/`.

Andere Unterlagen in der ZIP sind nur Anleitung und Prüfbericht.

### Klickfolge für Datei 1
1. ZIP-Paket hier herunterladen und **lokal entpacken**.
2. GitHub öffnen: https://github.com/oliverdejong0-sys/IVY11_GRRM_V1_RUNTIME
3. Reiter **Code**, Branch **main**.
4. Auf der obersten Dateiliste **Add file → Upload files** wählen.
5. Die lokale Datei **`base-parity-research-bundle.zip`** auswählen (nicht ihren Inhalt entpacken).
6. **Commit changes** bestätigen.

### Klickfolge für Datei 2
1. Im gleichen GitHub-Repository auf Ordner **`.github/workflows`** klicken.
2. **Add file → Upload files** auswählen.
3. Ausschließlich **`ivy11-base-v3-online-paritaet-readonly.yml`** aus dem lokal entpackten Ordner `.github/workflows` auswählen.
4. **Commit changes** bestätigen.

### Test starten
1. GitHub oben **Actions** anklicken.
2. Links **IVY11 BASE - V3 Online-Paritaet (READ ONLY)** wählen.
3. **Run workflow → Branch: main → Run workflow**.
4. Laufende Prüfung abwarten (kann mehrere Minuten dauern; ein rotes ❌ bedeutet NO-GO, das Archiv wird dennoch hochgeladen).
5. Im betreffenden Lauf **Summary** öffnen.
6. Nach unten zu **Artifacts** scrollen und
   **`IVY11_BASE_V3_VOLLSTAENDIGE_ONLINE_ABNAHME`** anklicken.
7. Die heruntergeladene ZIP hier im Chat hochladen.

Es ist KEIN Datumsfeld erforderlich: Der Test verwendet exakt den Marktstichtag aus
`docs/latest_fast_snapshot.json` des GitHub-Repositories. Ist dieser mehr als 5 Kalendertage alt,
bricht der Lauf bewusst ab (FAST vorab über den bestehenden Workflow aktualisieren; Datum nicht vortäuschen).

## Was der Workflow genau prüft (in Reihenfolge)
1. SHA-256 des Programmpakets: `6902ecd60f3e4e4435a9d2c0f2e7e9fe3cc6c292d2db0930a38f90bf2a330fd4`.
2. Sicherheits-Unit-Tests für unvollständige Daten, falschen Stichtag, API-Key-Leaks und Fail-Closed.
3. Historischer BASE-V3-Replay (9.287 Zeilen).
4. FAST-Schema und Marktstichtag (höchstens fünf Kalendertage alt).
5. FRED-API: vollständige Historie von VIXCLS, BAA10Y, AAA10Y, NFCI, T10Y3M und SAHMREALTIME; keine Kurzstichprobe und kein ungeprüfter Ersatz.
6. SPY Adjusted Close über die ursprüngliche yfinance-Quelle, kein Providerwechsel.
7. Shiller: Link von `https://shillerdata.com/` lesen, **vollständige** `ie_data.xls` herunterladen und CAPE-Monatswerte aus dem Originalfeld parsen.
8. BIS: Credit Gap `Q.US.P.A.C` und DSR `Q.US.P`, komplette offizielle CSVs, originaler BIS-Serienparser.
9. Ursprüngliche Action-Overlap-Parität (GQ), ursprüngliche BASE-Slow-Source-Parität (HG) ohne aufgeweichte Schwellen.
10. Quellen-Aktualität, berechneter BASE-Kandidat über unveränderten `HI` + rekonstruierten HE/HF; MSP-Market/Credit/Vol gegen bestehendes FAST.
11. Bei **jedem** Verstoß: NO-GO und kein BASE-Kandidat. Bei Erfolg: ausschließlich **RESEARCH_CANDIDATE_READY_REVIEW_REQUIRED**.
12. Keine Commit-/Push-Berechtigung. Der Workflow enthält keine automatische Publikation.

## Ergebnis auswerten
- `ONLINE_ABNAHME_STATUS.json`: `online_parity`, `release`, `errors`, Datum.
- `ONLINE_ABNAHME_GATES.csv`: jeder Prüfschritt mit PASS/FAIL.
- `source_manifest.json`: Quelle, Anzahl historischer Punkte, Zeitraum und Dateiprüfsummen.
- `base_parity_components.csv`: eingefrorener und neu berechneter Normalisierungswert, Differenz, ursprüngliche Toleranz.
- `candidate/`: NUR bei vollständig bestandenem Lauf, weiterhin NICHT produktiv freigegeben.
- `SHA256SUMS.txt`: Integritätsnachweis über die Ergebnisdateien.

**Falls NO-GO: Nicht erneut auf Verdacht ausführen, kein Datum ändern und keine BASE-Werte manuell ersetzen. Einfach Ergebnis-ZIP hier hochladen.**

## Methoden-/Datenstände sauber getrennt
- IVY GPT: V8.1
- GRRM Runtime-Revision: V6.3_CACHE_SAFE (Methodik, nicht Aktualitätsdatum)
- BASE eingefroren: 02.10.2026
- IVY Portfolio: 90% IVY4-aus-11 / 10% Gold; Regime rein diagnostisch.
- KEINE regimebasierte Cash-Logik.

## Webreferenzen
- FRED API-Dokumentation: https://fred.stlouisfed.org/docs/api/fred/series_observations.html
- Shiller offizielle Datenseite: https://shillerdata.com/
- BIS SDMX: https://stats.bis.org/api/v2/

## Warnung
Es werden nur die technischen Voraussetzungen für eine spätere Freigabe überprüft. Selbst
ein vollständig bestandenes Source-Gate ersetzt NICHT die separate menschliche
Prüfung des prospektiven Kandidaten. Die veröffentlichte Runtime bleibt unangetastet.
