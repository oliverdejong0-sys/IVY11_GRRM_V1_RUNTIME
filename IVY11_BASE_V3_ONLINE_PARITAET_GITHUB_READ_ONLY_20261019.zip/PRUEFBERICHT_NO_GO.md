# Technischer Prüfbericht – IVY11 BASE V3 Online-Quellenparität

## Datengrundlage
Vorliegender GitHub-Transportrun `IVY11_BASE_QUELLEN_GITHUB_ERGEBNIS.zip`:
9 von 9 Transporttests bestanden. `source_parity=NOT_TESTED`,
`base_refresh=NOT_PERFORMED`, `production_release=NO_GO`.
Diese Werte wurden nicht in eine Modellfreigabe umgedeutet.

## Getesteter Code
- Originale HE/HF sind verloren; verwendete HE/HF explizit `RESEARCH_ONLY_NONORIGINAL`.
- Originale GU, GT, HH, HI, GQ und HG als Byte-für-Byte-Kopien aus
  dem dokumentierten früheren Forschungsarchiv übernommen.
- Angepasst ausschließlich der research-only Online-Abnahme-Runner:
  `IVY11_BASE_Online_Abnahme.py` (kein Eingriff in die Modellschwellen).

## Lokal nachgewiesen am 19.10.2026
1. Python-Quellcodes im Bundle lassen sich kompilieren.
2. Historischer Replay 9.287/9.287 Regime, 0 Fehler; VP und MSP max.
   Absolutabweichung 4.263256414560601e-14.
3. 10/10 Tests in `TEST_Online_Safety_Offline.py` bestanden. Alle
   Netzwerkantworten in diesen Tests sind simuliert; sie belegen keine
   Live-Erreichbarkeit.
4. `source_fetch()` fordert vollständige statt gekürzter FRED-Historien an;
   Response-Länge wird gegen FRED `count` überprüft.
5. Aktuelle offizielle Shiller-Seite wird auf `ie_data.xls` abgefragt;
   Dateiformat, vollständiges Excel und CAPE-Verlauf werden geprüft.
6. Offizieller BIS-Parser verwendet; kein stiller Serienersatz.
7. API-Key darf nicht in Fehlerberichten erscheinen (Negativtest bestanden).
8. FAIL-CLOSED: falsch datierter FAST-Snapshot / gescheiterte Quelle
   führen zu NO-GO und entfernen angelegte Kandidatendateien.
9. GitHub-Workflow YAML geparst; Trigger nur `workflow_dispatch`,
   `permissions.contents=read`, kein Push/Commit, Artefakt wird auch bei
   Quellenfehlern gesichert.
10. Bundle-SHA256: `6902ecd60f3e4e4435a9d2c0f2e7e9fe3cc6c292d2db0930a38f90bf2a330fd4`; ZIP-integrität: PASS.

## Noch NICHT nachgewiesen
- Ausführung des vollständigen neuen Tests auf GitHub Actions.
- Vollständige Quellhistorien nach dem alten Modellstand; die alten historischen
  Normalisierungen können aufgrund Datenrevisionen scheitern.
- Erfolgreiche ursprüngliche BASE-Quellenparität (6 Slow-Metriken).
- Prospektive BASE-Regimefortschreibung mit aktuellen echten Daten.
- Aktualisierung von `docs/latest_full_risk_snapshot.json` (nicht vorgesehen).

## Bewertung
**NO-GO für produktive Veröffentlichung.**
Das Uploadpaket stellt einen nachvollziehbaren, schreibgeschützten Kandidaten-Prüflauf
bereit. Bis eine unabhängige Online-Abnahme bestanden ist, bleiben
BASE-Stand 02.10.2026 und `BASE_REFRESH_REQUIRED` technisch korrekt.

## Unverändert
- GPT-Wissensdateien und Anweisungen
- IVY4 Google-Colab-Notebook / Monats-CSV
- 90/10-Portfolio-Policy
- alle produktiven GitHub-FAST-/FULL-Snapshot-Skripte

## Nächster definierter Gate
GitHub Actions `IVY11 BASE - V3 Online-Paritaet (READ ONLY)` einmal ausführen;
Artifact analysieren, bei Mismatch Quelle und Score pro Komponenten-Zeile
dokumentiert vergleichen. Keine pauschale Toleranzerhöhung.
