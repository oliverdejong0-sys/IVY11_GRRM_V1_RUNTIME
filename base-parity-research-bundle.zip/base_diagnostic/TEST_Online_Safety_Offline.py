#!/usr/bin/env python3
"""Offline safety tests; NO HTTP, NO GitHub writes."""
import unittest, tempfile, pathlib, json, io, sys, importlib.util
from unittest import mock
import pandas as pd
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("ivy_online_test",HERE/"IVY11_BASE_Online_Abnahme.py")
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)

class Response:
    def __init__(self, data=None, text=None, status=200):
        self._data=data or {}; self._text=text or ""; self.status_code=status
        self.content=json.dumps(self._data).encode() if data is not None else self._text.encode()
    def raise_for_status(self):
        if self.status_code!=200:raise ValueError("HTTP failure")
    def json(self):return self._data
    @property
    def text(self):return self._text

class XlsResponse(Response):
    def __init__(self,raw):self.content=raw;self.status_code=200
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def iter_content(self,chunk_size):
        for i in range(0,len(self.content),chunk_size):
            yield self.content[i:i+chunk_size]

class API:
    def __init__(self,record_count=120,reported_count=None):
        self.calls=[];self.record_count=record_count;self.reported_count=reported_count
    def get(self,url,params=None,**kw):
        self.calls.append((url,params))
        rec=[{"date":(pd.Timestamp("2026-10-02")-pd.Timedelta(days=i)).date().isoformat(),
              "value":str(i)} for i in range(self.record_count)]
        return Response({"observations":rec,
                         "count": self.reported_count if self.reported_count is not None else len(rec)})

class FakeOfficialWebsite:
    def __init__(self,raw):self.raw=raw;self.calls=[]
    def get(self,url,**kw):
        self.calls.append(url)
        if url=="https://shillerdata.com/":
            return Response(text='<html><a href="https://img1.wsimg.com/abc/ie_data.xls">Download</a></html>')
        assert url=="https://img1.wsimg.com/abc/ie_data.xls"
        return XlsResponse(self.raw)

class OfflineSafety(unittest.TestCase):
    def test_fred_full_source_not_recent_sample(self):
        api=API();logs=[]
        v=m.request_official_fred(api,"VIXCLS","a"*32,logs)
        self.assertEqual(len(v),120)
        self.assertEqual(logs[0]["full_history_count"],120)
        self.assertNotIn("observation_start",api.calls[0][1])
        self.assertEqual(api.calls[0][1]["limit"],100000)
    def test_fred_partial_pagination_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError,"no fallback"):
            m.request_official_fred(API(120,121),"VIXCLS","a"*32,[])
    def test_no_api_key_rejected(self):
        with self.assertRaisesRegex(RuntimeError,"missing/invalid"):
            m.request_official_fred(API(),"VIXCLS","",[])
    def test_key_never_in_api_failure(self):
        secret="abcdefghijklmnopqrstuvwx12345678"
        class Broken:
            def get(self,*a,**kw):
                raise RuntimeError("https://api.stlouisfed.org/path?api_key="+secret)
        with self.assertRaises(RuntimeError) as cm:
            m.request_official_fred(Broken(),"VIXCLS",secret,[])
        self.assertNotIn(secret,str(cm.exception))
    def test_shiller_complete_xlsx_from_official_page(self):
        dates=pd.date_range("1900-01-31",periods=1530,freq="ME")
        rows=[["", ""] for _ in range(6)]+[["Date","CAPE"]]+[
            [float(f"{d.year}.{d.month:02}"),float(k+10)] for k,d in enumerate(dates)]
        f=io.BytesIO()
        with pd.ExcelWriter(f,engine="openpyxl") as w:
            pd.DataFrame(rows).to_excel(w,sheet_name="Data",header=False,index=False)
        dat,provider,raw=m.fetch_shiller_official(FakeOfficialWebsite(f.getvalue()))
        self.assertEqual(provider,"SHILLERDATA_OFFICIAL")
        self.assertEqual(len(dat),1530)
        self.assertEqual(str(dat.Date.max().date()),"2027-06-30")
    def test_shiller_bad_host_rejected(self):
        class Malicious:
            def get(self,*args,**kwargs):
                return Response(text='<a href="https://evil.example/ie_data.xls">Download</a>')
        with self.assertRaisesRegex(ValueError,"Untrusted"):
            m.fetch_shiller_official(Malicious())
    def test_shiller_partial_workbook_cannot_pass(self):
        with self.assertRaises(Exception):
            m.parse_shiller_cape(b"PK\x03\x04partial document")
    def test_bis_requires_original_series_parser(self):
        class Source:
            def get(self,url,**kw):
                return Response(text="TIME_PERIOD,OBS_VALUE,KEY\n2026-Q1,4.1,Q.US.P\n")
        class HH:
            def parse_bis_csv(self,raw,key):
                return pd.DataFrame({"Period":["2026-Q1"],"value":[4.1]})
        v,prov,raw=m.fetch_bis_official(Source(),HH(),"WS_DSR","Q.US.P")
        self.assertEqual(prov,"BIS_OFFICIAL_SDMX")
        self.assertEqual(float(v.value[0]),4.1)
    def test_fail_closed_no_candidate_on_failed_source(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);out=root/"output"
            fake_fast=root/"fast.json"
            fake_fast.write_text(json.dumps({
                "schema":"IVY11_GRRM_V1_FAST_DAILY_V1",
                "target_market_date":"2026-10-15"
            }))
            def denied(bundle,output,target_date,api_key,check_gate):
                (output/"candidate").mkdir(exist_ok=True)
                (output/"candidate"/"fake.csv").write_text("fake")
                return [("source_NFCI","FAIL","network unreachable")]
            with mock.patch.object(m,"source_fetch",denied):
                st=m.run_online(root,out,pd.Timestamp("2026-10-15"),"a"*32,fake_fast)
            self.assertEqual(st["release"],"NO_GO")
            self.assertFalse((out/"candidate").exists())
            self.assertEqual(st["online_parity"],"FAIL")
    def test_fast_target_mismatch_rejected_before_network(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);out=root/"output"
            f=root/"fast.json"
            f.write_text(json.dumps({"schema":"IVY11_GRRM_V1_FAST_DAILY_V1",
                                     "target_market_date":"2026-10-15"}))
            with mock.patch.object(m,"source_fetch") as fetch:
                st=m.run_online(root,out,pd.Timestamp("2026-10-14"),"a"*32,f)
                fetch.assert_not_called()
            self.assertEqual(st["release"],"NO_GO")

if __name__=="__main__":
    unittest.main(verbosity=2)
