#!/usr/bin/env python3
"""IVY11 BASE deployment gate - NO automatic approval/push.

Consumes the exact full online audit directory from GitHub Actions/Colab.
Writes approval artifacts only with explicit human attestation. Never alters
IVY4/GPT/FAST logic and never pushes to GitHub.
"""
from __future__ import annotations
import argparse, hashlib, json, shutil, sys
from pathlib import Path
import pandas as pd

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def approve(audit, fastjson, repo, reviewer, approved, acknowledge):
    if not approved or not acknowledge:
        raise ValueError("Both --approve and --acknowledge-nonoriginal are required.")
    if not reviewer or len(reviewer.strip()) < 3:
        raise ValueError("Named human approver required.")
    st=json.loads((audit/"ONLINE_ABNAHME_STATUS.json").read_text(encoding="utf-8"))
    required={"online_parity":"PASS","release":"RESEARCH_CANDIDATE_READY_REVIEW_REQUIRED",
              "production_state_mutated":False,"github_modified":False,
              "model_original_byte_identical":False}
    for k,v in required.items():
        if st.get(k)!=v:
            raise ValueError(f"online status invalid {k}: {st.get(k)}")
    gates=st["gate_results"]
    if not gates or any(g.get("status")!="PASS" for g in gates):
        raise ValueError("Not all source and parity gates passed.")
    for mandatory in ("action_frozen_overlap_parity","base_slow_frozen_history_parity",
                       "official_source_freshness","original_HI_prospective_REFRESH_CANDIDATE","fast_vs_base_action_parity"):
        if not any(g.get("step")==mandatory and g.get("status")=="PASS" for g in gates):
            raise ValueError(f"Missing mandatory gate {mandatory}")
    replay=audit/"offline_replay_stdout.txt"
    if not replay.exists():
        raise FileNotFoundError("Offline 9287-row replay evidence missing")
    rs=json.loads(replay.read_text(encoding="utf-8"))
    if not (rs.get("offline_result")=="PASS_CANONICAL_HISTORY" and
            rs.get("rows")==9287 and rs.get("regime_mismatches")==0 and
            float(rs.get("vp_max_abs_diff",1))<1e-12 and
            float(rs.get("msp_max_abs_diff",1))<1e-12):
        raise ValueError("Offline historical replay not independently confirmed")
    reference=audit/"fast_reference.json"
    if not reference.exists() or sha(reference)!=st.get("fast_reference_sha256"):
        raise ValueError("FAST reference/hash is not attached to audit evidence")
    fast=json.loads(fastjson.read_text(encoding="utf-8"))
    if sha(reference)!=sha(fastjson):
        raise ValueError("External FAST JSON differs from online-run reference")
    if fast.get("schema")!="IVY11_GRRM_V1_FAST_DAILY_V1":
        raise ValueError("FAST schema invalid")
    target=str(st["target_date"])
    if str(fast.get("target_market_date"))!=target:
        raise ValueError("FAST market date != candidate market date")
    csv=audit/"candidate/latest_base_candidate.csv"
    state=audit/"candidate/reconstructed_next_state_candidate.json"
    ledger=audit/"candidate/prospective_bridge_rows.csv"
    evidence=audit/"ONLINE_ABNAHME_GATES.csv"
    manifest=audit/"source_manifest.json"
    for f in (csv,state,ledger,evidence,manifest):
        if not f.is_file():raise FileNotFoundError(f)
    row=pd.read_csv(csv)
    if len(row)!=1 or str(row.iloc[0].Date)!=target:
        raise ValueError("BASE CSV rows/date invalid")
    if not (1 <= int(row.iloc[0]["BASE_REGIME"]) <= 7):
        raise ValueError("BASE regime invalid")
    for key in ("VP","MSP"):
        val=float(row.iloc[0][key])
        if not (0<=val<=100):raise ValueError(f"invalid {key}")
    if "PARITY=PASS" not in str(row.iloc[0].SOURCE_NOTE):
        raise ValueError("BASE candidate not parity-proofed")
    z=json.loads(state.read_text(encoding="utf-8"))
    if z.get("anchor_date")!=target or z.get("production_approved") is not False:
        raise ValueError("Reconstructed state status invalid")
    if z.get("reconstruction_status")!="RESEARCH_ONLY_NONORIGINAL":
        raise ValueError("Reconstructed state mislabeled")
    hist=pd.read_csv(ledger)
    if len(hist)<1 or str(hist.iloc[-1].Date)!=target:
        raise ValueError("Incomplete BASE calendar bridge ledger")
    if hist["Date"].duplicated().any():
        raise ValueError("Duplicated prospective bridge dates")
    dest=repo/"data"
    dest.mkdir(parents=True,exist_ok=True)
    names=[
        (csv,"IVY11_GRRM_V1_BASE_LATEST_APPROVED.csv"),
        (state,"IVY11_BASE_STATE_LATEST_APPROVED.json"),
        (ledger,"IVY11_BASE_LEDGER_LATEST_APPROVED.csv"),
    ]
    for f,name in names:shutil.copy2(f,dest/name)
    approval={
        "approval_state":"HUMAN_APPROVED_AFTER_ONLINE_PASS",
        "approved_by":reviewer,
        "approved_base_date":target,
        "online_source_parity":"PASS",
        "prospective_HI_refresh":"PASS",
        "offline_historical_replay":"PASS",
        "reconstruction_nonoriginal_acknowledged":True,
        "csv_sha256":sha(csv),
        "evidence_sha256":sha(evidence),
        "source_manifest_sha256":sha(manifest),
        "seed_sha256":sha(state),
        "ledger_sha256":sha(ledger),
        "note":"EXPLICIT HUMAN ATTESTATION only; source documents remain part of audit archive",
    }
    (dest/"IVY11_GRRM_V1_BASE_LATEST_APPROVED.json").write_text(
        json.dumps(approval,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return approval

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--audit-dir",required=True,type=Path)
    ap.add_argument("--fast-json",required=True,type=Path)
    ap.add_argument("--repo-dir",required=True,type=Path)
    ap.add_argument("--reviewer",required=True)
    ap.add_argument("--approve",action="store_true")
    ap.add_argument("--acknowledge-nonoriginal",action="store_true")
    args=ap.parse_args()
    approval=approve(args.audit_dir,args.fast_json,args.repo_dir,args.reviewer,
                    args.approve,args.acknowledge_nonoriginal)
    print(json.dumps(approval,indent=2))

if __name__=="__main__":
    main()
