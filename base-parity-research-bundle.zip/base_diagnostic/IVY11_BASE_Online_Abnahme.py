#!/usr/bin/env python3
"""IVY11 BASE online candidate - original scoring/refresh, official transport.

FAIL CLOSED. Creates audit candidate ONLY, never writes production state or GitHub.
Reconstructed HE/HF remain RESEARCH_ONLY until separately approved.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, importlib.util, io, json, os, subprocess, sys, shutil
from pathlib import Path
from urllib.parse import urlencode, urljoin, urlsplit
from html.parser import HTMLParser
import re

import numpy as np
import pandas as pd

ANCHOR = pd.Timestamp("2026-10-02")
SIDS = ("VIXCLS","BAA10Y","AAA10Y","NFCI","T10Y3M","SAHMREALTIME")
BASE_SIDS = {"NFCI","T10Y3M","SAHMREALTIME"}

def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,str(path))
    obj=importlib.util.module_from_spec(spec)
    sys.modules[name]=obj
    spec.loader.exec_module(obj)
    return obj

def check_csv(raw,series):
    x=pd.read_csv(io.BytesIO(raw))
    if len(x.columns)<2:
        raise ValueError("not a two-column observation CSV")
    cols=list(x.columns)
    d=pd.to_datetime(x[cols[0]],errors="coerce")
    v=pd.to_numeric(x[series] if series in cols else x[cols[1]],errors="coerce")
    out=pd.DataFrame({"Date":d,series:v}).dropna().sort_values("Date").drop_duplicates("Date",keep="last")
    if len(out)<10 or not out["Date"].is_monotonic_increasing:
        raise ValueError("too few/invalid observations")
    if out.Date.max()<ANCHOR:
        raise ValueError("source does not reach frozen anchor")
    return out

def request_official_fred(session,series,api_key,logs):
    """Only the documented FRED API, full historical series, fail closed."""
    if not re.fullmatch(r"[a-z0-9]{32}",api_key or ""):
        raise RuntimeError("FRED_API_KEY missing/invalid (secret is never logged)")
    endpoint="https://api.stlouisfed.org/fred/series/observations"
    args={"series_id":series,"api_key":api_key,"file_type":"json",
          "limit":100000,"sort_order":"asc"}
    try:
        r=session.get(endpoint,params=args,timeout=(8,25),
                      headers={"User-Agent":"IVY11 BASE parity research"})
        r.raise_for_status()
        obj=r.json()
        records=obj.get("observations")
        if not isinstance(records,list):
            raise ValueError("FRED response has no observations")
        # Explicitly reject a truncated response rather than accidentally
        # treating a recent-page sample as the full historical distribution.
        if int(obj.get("count",len(records)))!=len(records):
            raise ValueError("FRED API history is truncated/paginated")
        dates=pd.to_datetime([x.get("date") for x in records],errors="coerce")
        vals=pd.to_numeric([x.get("value") for x in records],errors="coerce")
        df=pd.DataFrame({"Date":dates,series:vals}).dropna()
        if df["Date"].duplicated().any():
            raise ValueError(f"FRED {series}: duplicate historical dates")
        df=df.sort_values("Date")
        if len(df)<100 or df.Date.max()<ANCHOR:
            raise ValueError(f"FRED {series}: historical coverage incomplete")
        logs.append({"series":series,"provider":"FRED_OFFICIAL_API",
                     "rows":len(df),"first":str(df.Date.min().date()),
                     "last":str(df.Date.max().date()),
                     "raw_sha256":hashlib.sha256(r.content).hexdigest(),
                     "full_history_count":len(records)})
        return df
    except Exception as exc:
        # Requests exceptions may contain the URL with the secret in query args.
        # Do NOT pass their repr or text into logs, artifacts or traceback.
        raise RuntimeError(
            f"Official FRED API {series} failed ({type(exc).__name__}); "
            "no fallback or synthetic values permitted"
        ) from None

class ShillerLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag.lower()!='a': return
        href=dict(attrs).get("href","")
        if urlsplit(href).path.lower().endswith("/ie_data.xls"):
            self.links.append(href)

def parse_shiller_cape(raw):
    """Match the frozen CAPE series choice and monthly dating rules."""
    if not(raw.startswith(bytes.fromhex("D0CF11E0")) or raw.startswith(b"PK\x03\x04")):
        raise ValueError("Shiller download is not an Excel workbook")
    last=None
    for skip in range(5,11):
        try:
            x=pd.read_excel(io.BytesIO(raw),sheet_name="Data",skiprows=skip)
            cols={str(c).strip().upper():c for c in x.columns}
            capecol=cols.get("CAPE")
            if capecol is None:
                capecol=next((v for k,v in cols.items() if "CAPE" in k),None)
            datecol=next((v for k,v in cols.items() if k=="DATE" or k.startswith("DATE.")),None)
            if capecol is None or datecol is None: continue
            dates=[]
            for v in x[datecol]:
                if pd.isna(v):
                    dates.append(pd.NaT);continue
                try:
                    num=float(v); year=int(num); month=int(round((num-year)*100))
                    if not(1871<=year<=2100 and 1<=month<=12):
                        raise ValueError("invalid Shiller fractional month")
                    dates.append(pd.Timestamp(year,month,1)+pd.offsets.MonthEnd(0))
                except Exception:
                    # Do not silently clamp invalid months to 1 or 12.
                    dates.append(pd.NaT)
            df=pd.DataFrame({"Date":dates,"value":pd.to_numeric(x[capecol],errors="coerce")})
            df=df.dropna().sort_values("Date")
            if df.Date.duplicated().any():
                raise ValueError("Shiller duplicate month")
            if len(df)<1000 or df.Date.min()>pd.Timestamp("1900-01-31") or df.Date.max()<ANCHOR:
                raise ValueError("Shiller historical CAPE coverage incomplete")
            return df
        except Exception as exc:
            last=type(exc).__name__
    raise RuntimeError(f"Could not parse official Shiller CAPE workbook ({last})")

def fetch_shiller_official(session):
    landing="https://shillerdata.com/"
    r=session.get(landing,timeout=(8,20),headers={"User-Agent":"IVY11 BASE research"})
    r.raise_for_status()
    parser=ShillerLinks();parser.feed(r.text)
    if not parser.links:
        raise ValueError("Shiller official page has no ie_data.xls link")
    url=urljoin(landing,parser.links[0])
    parts=urlsplit(url)
    if (parts.scheme!="https" or
        not(parts.hostname=="shillerdata.com" or
            (parts.hostname or "").endswith(".wsimg.com"))):
        raise ValueError("Untrusted Shiller workbook host")
    # Download the complete workbook. A prefix-only check is NOT parity.
    with session.get(url,timeout=(8,40),stream=True) as rr:
        rr.raise_for_status()
        blocks=[]; size=0
        for chunk in rr.iter_content(chunk_size=65536):
            size+=len(chunk)
            if size>15_000_000:
                raise ValueError("Shiller workbook over 15 MB limit")
            blocks.append(chunk)
    raw=b"".join(blocks)
    return parse_shiller_cape(raw),"SHILLERDATA_OFFICIAL",raw

def fetch_bis_official(session,hh,dataflow,key):
    url=f"https://stats.bis.org/api/v2/data/dataflow/BIS/{dataflow}/1.0/{key}"
    r=session.get(url,params={"format":"csvfile"},timeout=(8,45),
                  headers={"Accept":"text/csv","User-Agent":"IVY11 BASE parity research"})
    r.raise_for_status()
    if len(r.content)>20_000_000:
        raise ValueError("BIS file exceeds 20 MB")
    return hh.parse_bis_csv(r.content,key),"BIS_OFFICIAL_SDMX",r.content

def source_fetch(bundle,output,target_date,api_key,check_gate):
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    sess=requests.Session()
    adapter=HTTPAdapter(max_retries=Retry(total=1,connect=1,read=1,
                backoff_factor=0.5,status_forcelist=[429,502,503,504],
                allowed_methods=["GET"]))
    sess.mount("https://",adapter)
    adir=output/"raw_action";bdir=output/"raw_base"
    adir.mkdir(parents=True,exist_ok=True);bdir.mkdir(parents=True,exist_ok=True)
    logs=[];gate=[]
    for sid in SIDS:
        try:
            df=request_official_fred(sess,sid,api_key,logs)
            df.to_csv(adir/f"{sid}.csv",index=False)
            if sid in BASE_SIDS:
                df.rename(columns={sid:"value"}).to_csv(bdir/f"{sid}.csv",index=False)
            gate.append((f"source_{sid}","PASS",
                         f"FULL HISTORY {len(df)} rows; {df.Date.min().date()}..{df.Date.max().date()}"))
        except Exception as ex:
            gate.append((f"source_{sid}","FAIL",
                         f"{type(ex).__name__}: no complete historical data"))
    gt=load_module(bundle/"GT_original.py","ivy_gt_official_transport")
    try:
        spy=gt.fetch_spy_recent(
            start=(ANCHOR-pd.Timedelta(days=45)).date().isoformat(),
            end_exclusive=(target_date+pd.Timedelta(days=2)).date().isoformat())
        if len(spy)<8 or spy.Date.max()<target_date:
            raise ValueError("SPY source incomplete")
        spy.to_csv(adir/"SPY_recent.csv",index=False)
        logs.append({"series":"SPY","provider":"Yahoo adjusted close (frozen model)",
                     "rows":len(spy),"first":str(spy.Date.min().date()),
                     "last":str(spy.Date.max().date()),
                     "normalized_sha256":hashlib.sha256((adir/"SPY_recent.csv").read_bytes()).hexdigest()})
        gate.append(("source_SPY","PASS",f"{len(spy)} adjusted close rows"))
    except Exception as ex:
        gate.append(("source_SPY","FAIL",f"{type(ex).__name__}: source unavailable/incomplete"))
    hh=load_module(bundle/"HH_original.py","ivy_hh_official_slow")
    try:
        cape,prov,raw=fetch_shiller_official(sess)
        cape.to_csv(bdir/"CAPE_monthly.csv",index=False)
        logs.append({"series":"CAPE","provider":prov,"rows":len(cape),
                     "first":str(cape.Date.min().date()),"last":str(cape.Date.max().date()),
                     "raw_sha256":hashlib.sha256(raw).hexdigest()})
        gate.append(("source_CAPE","PASS",f"FULL workbook {len(cape)} months"))
    except Exception as ex:
        gate.append(("source_CAPE","FAIL",f"{type(ex).__name__}: incomplete official workbook"))
    for flow,key,name in (("WS_CREDIT_GAP","Q.US.P.A.C","BIS_CREDIT_GAP"),
                          ("WS_DSR","Q.US.P","BIS_DSR")):
        try:
            dat,prov,raw=fetch_bis_official(sess,hh,flow,key)
            if len(dat)<40:raise ValueError("BIS history too short")
            dat.to_csv(bdir/f"{name}.csv",index=False)
            logs.append({"series":name,"provider":prov,"rows":len(dat),
                         "first":str(dat.Period.min()),"last":str(dat.Period.max()),
                         "raw_sha256":hashlib.sha256(raw).hexdigest()})
            gate.append((f"source_{name}","PASS",f"FULL CSV {len(dat)} quarters"))
        except Exception as ex:
            gate.append((f"source_{name}","FAIL",f"{type(ex).__name__}: official BIS full series unavailable"))
    for record in logs:
        ser=record["series"]
        if ser=="SPY": p=adir/"SPY_recent.csv"
        elif ser in SIDS: p=adir/f"{ser}.csv"
        elif ser=="CAPE":p=bdir/"CAPE_monthly.csv"
        else:p=bdir/f"{ser}.csv"
        if p.exists():
            record["normalized_file_sha256"]=hashlib.sha256(p.read_bytes()).hexdigest()
    (output/"source_manifest.json").write_text(
        json.dumps(logs,indent=2,ensure_ascii=False),encoding="utf-8")
    (bdir/"BASE_diagnostic_acquisition_metadata.json").write_text(
        json.dumps({"provider":"verified official historical source families",
                    "sources":logs},indent=2),encoding="utf-8")
    return gate

def validate_action(bundle,output,target):
    gu=load_module(bundle/"GU_original.py","ivy_gu_parity")
    adir=output/"raw_action"
    anchor=pd.read_csv(bundle/"GQ_original.csv",parse_dates=["Date"]).sort_values("Date")
    spy=pd.read_csv(adir/"SPY_recent.csv",parse_dates=["Date"])
    eq,_=gu.build_equity_continuation(anchor,spy,ANCHOR)
    market,_,_=gu.market_score_from_equity(eq,ANCHOR)
    vix=pd.read_csv(adir/"VIXCLS.csv")
    baa=pd.read_csv(adir/"BAA10Y.csv")
    aaa=pd.read_csv(adir/"AAA10Y.csv")
    vol,_,_=gu.native_current_score(vix,"VIXCLS",ANCHOR,True)
    bscore,_,_=gu.native_current_score(baa,"BAA10Y",ANCHOR,True)
    ascore,_,_=gu.native_current_score(aaa,"AAA10Y",ANCHOR,True)
    return gu.source_overlap_gate(anchor,adir,ANCHOR,market,vol,
                                  float(np.mean([bscore,ascore])))

def validate_source_freshness(output,target):
    adir=output/"raw_action";bdir=output/"raw_base"
    spy=pd.read_csv(adir/"SPY_recent.csv",parse_dates=["Date"])
    vix=pd.read_csv(adir/"VIXCLS.csv",parse_dates=["Date"])
    for name,df in [("SPY",spy),("VIXCLS",vix)]:
        if target not in set(df.Date.dt.normalize()):
            raise ValueError(f"{name}: no final observation at target {target.date()}")
    for name in ("BAA10Y","AAA10Y","T10Y3M"):
        df=pd.read_csv(adir/f"{name}.csv",parse_dates=["Date"])
        prev=df.loc[df.Date<=target,"Date"].max()
        if pd.isna(prev) or (target-prev).days>4:
            raise ValueError(f"{name}: last observation {prev}, stale for {target.date()}")
    # Slow macro release lags handled by original HI; stale required series fail via it.

def safe_run(command,timeout=120):
    r=subprocess.run(command,capture_output=True,text=True,timeout=timeout)
    if r.returncode:
        raise RuntimeError(f"exit={r.returncode}; stdout={r.stdout[-2000:]}; stderr={r.stderr[-1500:]}")
    return r.stdout[-2000:]

def run_online(bundle,output,target,api_key=None,fast_reference=None):
    output.mkdir(parents=True,exist_ok=True)
    gate=[];errors=[];prospective=None
    def step(name,fn):
        try:
            detail=fn()
            gate.append({"step":name,"status":"PASS","detail":str(detail)[:1000]})
            print("PASS",name,flush=True)
            return True
        except Exception as e:
            gate.append({"step":name,"status":"FAIL","detail":repr(e)[:2000]})
            errors.append(name+": "+repr(e))
            print("FAIL",name,repr(e)[:500],flush=True)
            return False
    status={"release":"NO_GO","target_date":target.date().isoformat(),
            "frozen_anchor_date":ANCHOR.date().isoformat(),
            "online_parity":"NOT_TESTED","production_state_mutated":False,
            "github_modified":False,"model_original_byte_identical":False,
            "model":"RECONSTRUCTED_RESEARCH_ONLY",
            "started_utc":dt.datetime.now(dt.timezone.utc).isoformat()}
    try:
        if target<=ANCHOR or target.weekday()>=5:
            raise ValueError("Target must be a business weekday after 2026-10-02.")
        if fast_reference is None:
            raise ValueError("A verified FAST snapshot JSON is required.")
        fast=json.loads(Path(fast_reference).read_text(encoding="utf-8"))
        if fast.get("schema")!="IVY11_GRRM_V1_FAST_DAILY_V1":
            raise ValueError("FAST schema invalid.")
        if fast.get("target_market_date")!=target.date().isoformat():
            raise ValueError("Target must match FAST market date.")
        if (dt.datetime.now(dt.timezone.utc).date()-target.date()).days not in range(0,6):
            raise ValueError("FAST market date older than 5 calendar days or future.")
        status["fast_reference_sha256"]=hashlib.sha256(Path(fast_reference).read_bytes()).hexdigest()
        src_gate=source_fetch(bundle,output,target,api_key,True)
        for name,s,info in src_gate:
            gate.append({"step":name,"status":s,"detail":info})
        if any(s!="PASS" for _,s,_ in src_gate):
            errors.append("Required official source acquisition failed.")
        else:
            step("action_frozen_overlap_parity",lambda:validate_action(bundle,output,target))
            hi=load_module(bundle/"HI_original.py","ivy_hi_online_check")
            def base_parity():
                src=hi.load_diag_sources(output/"raw_base")
                table,ok=hi.anchor_parity(bundle/"HG_original.csv",src)
                table.to_csv(output/"base_parity_components.csv",index=False)
                if not ok: raise RuntimeError(table.loc[~table["pass"]].to_json(orient="records"))
                return "All six original slow-component tolerances satisfied."
            step("base_slow_frozen_history_parity",base_parity)
            step("official_source_freshness",lambda:validate_source_freshness(output,target))
            if not errors:
                def prospective_refresh():
                    nonlocal prospective
                    candidate=output/"candidate";candidate.mkdir(exist_ok=True)
                    command=[
                        sys.executable,str(bundle/"HI_original.py"),
                        "--base-kernel",str(bundle/"HE_rekonstruktion.py"),
                        "--base-state-seed",str(bundle/"HF_rekonstruktion.json"),
                        "--component-anchor",str(bundle/"HG_original.csv"),
                        "--action-producer-module",str(bundle/"GU_original.py"),
                        "--action-anchor",str(bundle/"GQ_original.csv"),
                        "--action-rawdir",str(output/"raw_action"),
                        "--diagnostic-rawdir",str(output/"raw_base"),
                        "--target-date",target.date().isoformat(),
                        "--out",str(candidate/"latest_base_candidate.csv"),
                        "--components-out",str(candidate/"prospective_bridge_rows.csv"),
                        "--parity-out",str(candidate/"source_parity.csv"),
                        "--updated-state-seed-out",str(candidate/"reconstructed_next_state_candidate.json"),
                    ]
                    prospective=safe_run(command,timeout=240)
                    row=pd.read_csv(candidate/"latest_base_candidate.csv")
                    newseed=json.loads((candidate/"reconstructed_next_state_candidate.json").read_text())
                    if len(row)!=1 or str(row.iloc[0].Date)!=target.date().isoformat():
                        raise RuntimeError("candidate BASE date mismatch")
                    if "PARITY=PASS" not in str(row.iloc[0].SOURCE_NOTE):
                        raise RuntimeError("candidate missing parity proof")
                    if newseed.get("anchor_date")!=target.date().isoformat() or newseed.get("production_approved") is not False:
                        raise RuntimeError("candidate next-state status invalid")
                    return prospective
                if step("original_HI_prospective_REFRESH_CANDIDATE",prospective_refresh):
                    def fast_crosscheck():
                        rows=pd.read_csv(output/"candidate/prospective_bridge_rows.csv")
                        curr=rows.iloc[-1]
                        snapshot=json.loads(Path(fast_reference).read_text(encoding="utf-8"))
                        x=snapshot["values"]
                        tolerance={"MSP_MARKET":0.30,"MSP_CREDIT_CONTROL":0.30,"MSP_VOL":0.10}
                        diffs={}
                        for col,tol in tolerance.items():
                            diff=abs(float(curr[col])-float(x[col]))
                            diffs[col]={"candidate":float(curr[col]),"published_fast":float(x[col]),
                                       "abs_diff":diff,"max_allowed":tol}
                            if diff>tol:
                                raise ValueError(f"{col} diverges from official FAST snapshot: {diff:.6g} > {tol}")
                        (output/"fast_crosscheck.json").write_text(json.dumps(diffs,indent=2),encoding="utf-8")
                        return "Market/Credit/Vol align with FAST "+json.dumps(diffs)
                    step("fast_vs_base_action_parity",fast_crosscheck)
        status["online_parity"]="PASS" if not errors else "FAIL"
        if not errors:
            status["release"]="RESEARCH_CANDIDATE_READY_REVIEW_REQUIRED"
            status["notes"]="All tested source/history/refresh gates passed; reconstructed kernel NOT independently forward-validated, NOT live-approved."
        else:
            status["notes"]="Fail closed: no approved BASE or updated production state generated."
    except Exception as exc:
        errors.append(repr(exc)); status["online_parity"]="FAIL"
        gate.append({"step":"runner","status":"FAIL","detail":repr(exc)})
    finally:
        if errors:
            shutil.rmtree(output/"candidate",ignore_errors=True)
        status["gate_results"]=gate
        status["errors"]=errors
        status["finished_utc"]=dt.datetime.now(dt.timezone.utc).isoformat()
        (output/"ONLINE_ABNAHME_STATUS.json").write_text(json.dumps(status,indent=2,ensure_ascii=False),encoding="utf-8")
        pd.DataFrame(gate,columns=["step","status","detail"]).to_csv(output/"ONLINE_ABNAHME_GATES.csv",index=False)
    return status

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--bundle-dir",required=True)
    ap.add_argument("--output-dir",required=True)
    ap.add_argument("--target-date",required=True)
    ap.add_argument("--fast-json",required=True)
    args=ap.parse_args()
    st=run_online(Path(args.bundle_dir),Path(args.output_dir),
        pd.Timestamp(args.target_date).normalize(),os.environ.get("FRED_API_KEY"),
        Path(args.fast_json))
    print(json.dumps({k:v for k,v in st.items() if k!="gate_results"},indent=2,ensure_ascii=False))
    # Fail closed but always write audit evidence.
    if st["release"]=="NO_GO":raise SystemExit(2)

if __name__=="__main__":
    main()
