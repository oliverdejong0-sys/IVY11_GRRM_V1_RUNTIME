"""Verifying reconstructed kernel against canonical historical HG; offline only."""
from pathlib import Path
import importlib.util
import json
import pandas as pd
import numpy as np

HERE=Path(__file__).resolve().parent
KERNEL=HERE/"original_pruefdateien/HE_rekonstruktion.py"
SEED=HERE/"original_pruefdateien/HF_rekonstruktion.json"
ANCHOR=HERE/"original_pruefdateien/HG_original.csv"
spec=importlib.util.spec_from_file_location("base_recovery", KERNEL)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

assert json.loads(SEED.read_text())["production_approved"] is False
df=pd.read_csv(ANCHOR)
assert df.Date.iloc[0]=="1990-01-02"
assert df.Date.iloc[-1]=="2026-10-02"
assert len(df)==9287

a=mod.BaseV3LiveKernel(prev_regime=5, fallrun=0)
nmis=0; maxvp=0.; maxmsp=0.
for r in df.itertuples(index=False):
    z=a.update(r.MSP_MARKET, r.MSP_CREDIT_CONTROL, r.N_NFCI,
               r.MSP_VOL, r.VP_VALUATION, r.VP_CURVE,
               r.VP_CREDITCYCLE, r.MACRO_CONFIRM, r.MSP_D20)
    nmis += int(z["BASE_REGIME"]!=int(r.BASE_V3_REGIME))
    maxvp=max(maxvp,abs(z["VP"]-r.VP))
    maxmsp=max(maxmsp,abs(z["MSP"]-r.MSP))
assert nmis==0,(nmis,"regime mismatches")
assert maxvp<1e-12 and maxmsp<1e-12
assert (a.prev_regime,a.fallrun)==(4,0)

seed=mod.BaseV3LiveKernel.from_seed_file(SEED)
assert seed.prev_regime==a.prev_regime
assert seed.fallrun==a.fallrun

print(json.dumps({
 "offline_result":"PASS_CANONICAL_HISTORY",
 "rows":len(df),"regime_mismatches":nmis,
 "vp_max_abs_diff":maxvp,"msp_max_abs_diff":maxmsp,
 "seed_regime":a.prev_regime,"seed_fallrun":a.fallrun,
 "online_parity":"NOT_TESTED","release":"NO_GO"
}, indent=2))
