
"""
IVY11_GRRM_V1-GT — Live Data Acquirer

Acquires source data only. It does not calculate portfolio decisions.

Sources:
- SPY adjusted close: Yahoo Finance via yfinance. No alternate provider substitution.
- VIXCLS, BAA10Y, AAA10Y: FRED primary; ALFRED fallback.
- NFCI, T10Y3M are also acquired for the separate BASE diagnostic updater.

Fail-closed principle:
If a required source cannot be obtained or is stale, no live snapshot should be emitted.
"""
from __future__ import annotations
import argparse, io, json, hashlib, datetime as dt, time
from pathlib import Path
import pandas as pd
import numpy as np

def ensure_requests():
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    session=requests.Session()
    retry=Retry(
        total=5,connect=5,read=5,backoff_factor=2,
        status_forcelist=[429,500,502,503,504],
        allowed_methods=["GET"]
    )
    session.mount("https://",HTTPAdapter(max_retries=retry))
    return session

def normalize_fred_bytes(raw: bytes, series_id: str) -> pd.DataFrame:
    x=pd.read_csv(io.BytesIO(raw))
    if x.shape[1]<2:
        raise ValueError(f"{series_id}: malformed CSV.")
    dcol=x.columns[0]
    vcol=[c for c in x.columns if c!=dcol][0]
    out=pd.DataFrame({
        "Date":pd.to_datetime(x[dcol],errors="coerce"),
        series_id:pd.to_numeric(x[vcol],errors="coerce")
    }).dropna().sort_values("Date").drop_duplicates("Date")
    if out.empty:
        raise ValueError(f"{series_id}: no valid observations.")
    return out

def fetch_fred(series_id: str, session):
    ua="IVY11_GRRM_V1 live shadow research (noncommercial)"
    urls=[
        ("FRED",f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={series_id}"),
        ("ALFRED",f"https://alfred.stlouisfed.org/graph/alfredgraph.csv?id={series_id}"),
    ]
    errs=[]
    for source,url in urls:
        try:
            r=session.get(url,headers={"User-Agent":ua},timeout=(20,180))
            r.raise_for_status()
            raw=r.content
            df=normalize_fred_bytes(raw,series_id)
            return df,source,hashlib.sha256(raw).hexdigest()
        except Exception as e:
            errs.append(f"{source}: {e!r}")
    raise RuntimeError(f"{series_id}: all Fed download paths failed. {errs}")

def fetch_spy_recent(start: str, end_exclusive: str):
    try:
        import yfinance as yf
    except Exception as e:
        raise RuntimeError("yfinance is required for SPY source parity.") from e

    d=yf.download(
        "SPY",
        start=start,
        end=end_exclusive,
        auto_adjust=False,
        actions=False,
        progress=False,
        threads=False,
    )
    if d is None or d.empty:
        raise RuntimeError("SPY Yahoo Finance download is empty.")

    if isinstance(d.columns,pd.MultiIndex):
        if "Adj Close" not in d.columns.get_level_values(0):
            raise RuntimeError("SPY source has no Adj Close column.")
        s=d["Adj Close"].iloc[:,0]
    else:
        if "Adj Close" not in d.columns:
            raise RuntimeError("SPY source has no Adj Close column.")
        s=d["Adj Close"]

    s=pd.to_numeric(s,errors="coerce").dropna()
    s.index=pd.to_datetime(s.index).tz_localize(None)
    out=s.rename("SPY_ADJ_CLOSE").reset_index()
    out.columns=["Date","SPY_ADJ_CLOSE"]
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--outdir",required=True)
    ap.add_argument("--target-date",required=True)
    ap.add_argument("--spy-lookback-days",type=int,default=20)
    ap.add_argument("--spy-anchor-date",default="2026-10-02")
    args=ap.parse_args()

    out=Path(args.outdir); out.mkdir(parents=True,exist_ok=True)
    target=pd.Timestamp(args.target_date).normalize()

    session=ensure_requests()
    meta={
        "acquired_utc":dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "target_date":str(target.date()),
        "sources":{},
    }

    for sid in ["VIXCLS","BAA10Y","AAA10Y","NFCI","T10Y3M","SAHMREALTIME"]:
        df,src,sha=fetch_fred(sid,session)
        p=out/f"{sid}.csv"
        df.to_csv(p,index=False)
        meta["sources"][sid]={
            "provider":src,
            "sha256":sha,
            "first_date":str(df.Date.min().date()),
            "last_date":str(df.Date.max().date()),
            "rows":len(df),
        }

    rolling_start=target-pd.Timedelta(days=args.spy_lookback_days)
    frozen_anchor=pd.Timestamp(args.spy_anchor_date).normalize()
    start=min(rolling_start,frozen_anchor).date().isoformat()
    end=(target+pd.Timedelta(days=2)).date().isoformat()
    spy=fetch_spy_recent(start,end)
    spy.to_csv(out/"SPY_recent.csv",index=False)
    meta["sources"]["SPY"]={
        "provider":"Yahoo Finance via yfinance",
        "first_date":str(spy.Date.min().date()),
        "last_date":str(spy.Date.max().date()),
        "rows":len(spy),
        "sha256":hashlib.sha256((out/"SPY_recent.csv").read_bytes()).hexdigest(),
    }

    # Fail closed on target-date market data.
    if target not in set(spy.Date.dt.normalize()):
        raise RuntimeError(f"SPY has no finalized observation for target date {target.date()}.")
    vix=pd.read_csv(out/"VIXCLS.csv",parse_dates=["Date"])
    if target not in set(vix.Date.dt.normalize()):
        raise RuntimeError(f"VIXCLS has no finalized observation for target date {target.date()}.")

    # Credit may publish with a short lag. Maximum 4 calendar days is allowed;
    # exact source date is retained for the snapshot note.
    for sid in ["BAA10Y","AAA10Y"]:
        x=pd.read_csv(out/f"{sid}.csv",parse_dates=["Date"]).dropna()
        latest=x.loc[x.Date<=target,"Date"].max()
        if pd.isna(latest) or (target-latest).days>4:
            raise RuntimeError(f"{sid} is stale for target {target.date()}: latest {latest}.")

    (out/"acquisition_metadata.json").write_text(
        json.dumps(meta,indent=2),encoding="utf-8"
    )
    print(json.dumps(meta,indent=2))

if __name__=="__main__":
    main()
