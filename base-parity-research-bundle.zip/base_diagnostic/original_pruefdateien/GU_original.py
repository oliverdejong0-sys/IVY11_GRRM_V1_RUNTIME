
"""
IVY11_GRRM_V1-GU — Live Shadow Snapshot Producer

Consumes:
- frozen action anchor;
- frozen CLEAN3F incremental state seed;
- raw source files from IVY11_GRRM_V1-GT_Live_Data_Acquirer.py;
- a BASE diagnostic row;
- a frozen IVY11 state row.

Produces one normalized snapshot row compatible with the append-only Shadow Decision Runner.

Fail-closed:
- no provider substitution for SPY;
- source overlap parity must pass;
- target SPY and VIX observations must exist;
- credit staleness <= 4 calendar days;
- BASE diagnostic staleness <= 7 calendar days in calm state;
- BASE diagnostic must be same-date if either Sentinel or CLEAN3F is in stress;
- IVY signal invariants must pass.

No live-capital authority.
"""
from __future__ import annotations
import argparse, json, hashlib, importlib.util, sys
from pathlib import Path
import pandas as pd
import numpy as np

def load_kernel(path):
    spec=importlib.util.spec_from_file_location("ivy_clean_live_kernel",path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules["ivy_clean_live_kernel"]=mod
    spec.loader.exec_module(mod)
    return mod

def current_percentile(values, x):
    a=pd.to_numeric(pd.Series(values),errors="coerce").dropna().to_numpy(float)
    if len(a)==0 or pd.isna(x):
        return np.nan
    return float(100.0*(np.sum(a<=float(x))-0.5)/len(a))

def native_current_score(df, col, target_date, adverse_high=True):
    q=df.copy()
    q["Date"]=pd.to_datetime(q["Date"])
    q[col]=pd.to_numeric(q[col],errors="coerce")
    q=q[(q.Date<=target_date)&q[col].notna()].sort_values("Date")
    if q.empty:
        raise ValueError(f"{col}: no observation by target date.")
    row=q.iloc[-1]
    x=float(row[col])
    p=current_percentile(q[col],x)
    return (p if adverse_high else 100-p), pd.Timestamp(row.Date), x

def build_equity_continuation(anchor, spy, target):
    a=anchor[["Date","EQUITY"]].copy()
    a["Date"]=pd.to_datetime(a["Date"])
    a["EQUITY"]=pd.to_numeric(a["EQUITY"],errors="coerce")
    a=a.dropna().sort_values("Date")
    anchor_end=a.Date.max()
    anchor_val=float(a.loc[a.Date==anchor_end,"EQUITY"].iloc[-1])

    spy=spy.copy()
    spy["Date"]=pd.to_datetime(spy["Date"])
    spy["SPY_ADJ_CLOSE"]=pd.to_numeric(spy["SPY_ADJ_CLOSE"],errors="coerce")
    spy=spy.dropna().sort_values("Date").drop_duplicates("Date")

    if target<=anchor_end:
        # Historical dry-run / parity mode.
        bcal=pd.bdate_range(a.Date.min(),target)
        eq=a.set_index("Date").EQUITY.reindex(bcal).ffill()
        return eq,anchor_end

    ref=spy.loc[spy.Date==anchor_end,"SPY_ADJ_CLOSE"]
    if ref.empty:
        raise ValueError(f"SPY recent source must contain frozen anchor date {anchor_end.date()}.")
    ref=float(ref.iloc[-1])

    new=spy[(spy.Date>anchor_end)&(spy.Date<=target)].copy()
    if new.empty or target not in set(new.Date.dt.normalize()):
        raise ValueError(f"SPY has no target-date observation {target.date()}.")

    new["EQUITY_CONTINUED"]=anchor_val*(new.SPY_ADJ_CLOSE/ref)

    # Build a business-weekday master exactly like the research feature master:
    # market holidays are forward-filled and therefore remain part of rolling feature history.
    bcal=pd.bdate_range(a.Date.min(),target)
    eq=a.set_index("Date").EQUITY.reindex(bcal)
    for _,r in new.iterrows():
        if r.Date in eq.index:
            eq.loc[r.Date]=float(r.EQUITY_CONTINUED)
    eq=eq.ffill()
    return eq,anchor_end

def market_score_from_equity(eq,target):
    px=eq.astype(float)
    f=pd.DataFrame(index=px.index)
    f["EQ_MA200_GAP"]=100*(px/px.rolling(200).mean()-1)
    f["EQ_MOM6"]=100*(px/px.shift(126)-1)
    f["EQ_MOM12"]=100*(px/px.shift(252)-1)
    f["EQ_DRAWDOWN"]=100*(px/px.cummax()-1)

    if target not in f.index:
        raise ValueError(f"Target {target.date()} is not in business-day equity master.")
    cur=f.loc[target]
    scores={}
    for c in ["EQ_MA200_GAP","EQ_MOM6","EQ_MOM12","EQ_DRAWDOWN"]:
        hist=f.loc[:target,c].dropna()
        p=current_percentile(hist,cur[c])
        scores[c]=float(100-p)  # adverse low
    return float(np.mean(list(scores.values()))), float(cur["EQ_MA200_GAP"]), scores

def source_overlap_gate(anchor, rawdir, target, market_score, vix_score, credit_score,
                        market_tol=.30, vol_tol=.10, credit_tol=.30):
    # Score-level gate at frozen anchor end. Market score is tested separately in dry-run;
    # VIX/credit raw source histories are checked on recent overlapping dates.
    rawdir=Path(rawdir)
    fp={}
    a=anchor.set_index("Date").sort_index()
    anchor_end=a.index.max()

    for sid,tol in [("VIXCLS",0.02),("BAA10Y",0.02),("AAA10Y",0.02)]:
        p=rawdir/f"{sid}.csv"
        x=pd.read_csv(p,parse_dates=["Date"]).set_index("Date")
        col=sid
        common=a.index.intersection(x.index)
        common=common[common>=anchor_end-pd.Timedelta(days=120)]
        if len(common)==0:
            raise ValueError(f"{sid}: no recent overlap with frozen anchor.")
        acol={"VIXCLS":"VIX","BAA10Y":"BAA10Y","AAA10Y":"AAA10Y"}[sid]
        dif=(pd.to_numeric(x.loc[common,col],errors="coerce")-
             pd.to_numeric(a.loc[common,acol],errors="coerce")).abs().dropna()
        if dif.empty:
            raise ValueError(f"{sid}: overlap contains no numeric values.")
        mx=float(dif.max())
        fp[f"{sid}_raw_max_abs_diff"]=mx
        if mx>tol:
            raise ValueError(f"{sid}: frozen overlap parity failed, max abs diff {mx} > {tol}.")

    # If target itself is the anchor end (dry run), enforce score parity tightly.
    if target==anchor_end:
        diffs={
            "MSP_MARKET":abs(float(market_score)-float(a.loc[target,"MSP_MARKET"])),
            "MSP_VOL":abs(float(vix_score)-float(a.loc[target,"MSP_VOL"])),
            "MSP_CREDIT_CONTROL":abs(float(credit_score)-float(a.loc[target,"MSP_CREDIT_CONTROL"])),
        }
        fp.update({f"{k}_score_abs_diff":v for k,v in diffs.items()})
        if diffs["MSP_MARKET"]>market_tol:
            raise ValueError(f"Market score parity failed: {diffs['MSP_MARKET']}.")
        if diffs["MSP_VOL"]>vol_tol:
            raise ValueError(f"VIX score parity failed: {diffs['MSP_VOL']}.")
        if diffs["MSP_CREDIT_CONTROL"]>credit_tol:
            raise ValueError(f"Credit score parity failed: {diffs['MSP_CREDIT_CONTROL']}.")
    return fp

def read_one_row(path, label):
    x=pd.read_csv(path)
    if len(x)!=1:
        raise ValueError(f"{label} must contain exactly one row.")
    return x.iloc[0]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--kernel",required=True)
    ap.add_argument("--anchor",required=True)
    ap.add_argument("--state-seed",required=True)
    ap.add_argument("--rawdir",required=True)
    ap.add_argument("--base-row",required=True)
    ap.add_argument("--ivy-state",required=True)
    ap.add_argument("--target-date",required=True)
    ap.add_argument("--out",required=True)
    ap.add_argument("--updated-seed-out",required=True)
    ap.add_argument("--action-components-out",
                    help="Optional sidecar with Market/Credit/Vol scores for BASE diagnostic refresher.")
    ap.add_argument("--dry-run",action="store_true")
    ap.add_argument("--offline-parity",action="store_true",
                    help="Use frozen anchor score components for assembly/parity QA; never for live evidence.")
    args=ap.parse_args()

    target=pd.Timestamp(args.target_date).normalize()
    rawdir=Path(args.rawdir)
    anchor=pd.read_csv(args.anchor,parse_dates=["Date"]).sort_values("Date")
    anchor_end=anchor.Date.max()

    if args.offline_parity:
        if target not in set(anchor.Date.dt.normalize()):
            raise ValueError("Offline parity target must exist in frozen anchor.")
        ar=anchor.loc[anchor.Date.dt.normalize()==target].iloc[-1]
        market_score=float(ar["MSP_MARKET"])
        ma200_gap=float(ar["EQ_MA200_GAP"])
        vix_score=float(ar["MSP_VOL"])
        credit_score=float(ar["MSP_CREDIT_CONTROL"])
        vix_date=baa_date=aaa_date=target
        vix_val=float(ar["VIX"]); baa_val=float(ar["BAA10Y"]); aaa_val=float(ar["AAA10Y"])
        parity={"offline_frozen_anchor_score_mode":True}
    else:
        spy=pd.read_csv(rawdir/"SPY_recent.csv",parse_dates=["Date"])
        eq,_=build_equity_continuation(anchor,spy,target)
        market_score,ma200_gap,market_parts=market_score_from_equity(eq,target)

        vix=pd.read_csv(rawdir/"VIXCLS.csv")
        baa=pd.read_csv(rawdir/"BAA10Y.csv")
        aaa=pd.read_csv(rawdir/"AAA10Y.csv")
        vix_score,vix_date,vix_val=native_current_score(vix,"VIXCLS",target,True)
        baa_score,baa_date,baa_val=native_current_score(baa,"BAA10Y",target,True)
        aaa_score,aaa_date,aaa_val=native_current_score(aaa,"AAA10Y",target,True)
        credit_score=float(np.mean([baa_score,aaa_score]))

        if vix_date!=target:
            raise ValueError(f"VIX target-date observation missing: latest {vix_date.date()}.")
        if (target-baa_date).days>4 or (target-aaa_date).days>4:
            raise ValueError("Credit source stale beyond four calendar days.")

        parity=source_overlap_gate(anchor,rawdir,target,market_score,vix_score,credit_score)

    kernel_mod=load_kernel(args.kernel)
    kernel=kernel_mod.Clean3FLiveKernel.from_seed_file(args.state_seed)

    # State seed is anchored at a fixed date. For live continuation, rawdir must contain every
    # target market day after the seed. The producer currently emits exactly one target row, so
    # the first live target must be the next actual SPY observation after the seed anchor.
    seed_info=json.loads(Path(args.state_seed).read_text(encoding="utf-8"))
    seed_date=pd.Timestamp(seed_info["anchor_date"])
    if not args.dry_run and target<=seed_date:
        raise ValueError("Live target must be strictly after CLEAN3F state seed date.")

    if args.dry_run:
        # For parity dry-runs at/before the anchor, rebuild state from the frozen anchor score history
        # instead of mutating the operational seed backwards.
        k=kernel_mod.build_seed_from_score_history(
            anchor.set_index("Date")[["MSP_MARKET","MSP_CREDIT_CONTROL","MSP_VOL"]],
            target-pd.Timedelta(days=1)
        )
        action=k.update(market_score,credit_score,vix_score)
    else:
        action=kernel.update(market_score,credit_score,vix_score)

    clean_stress=bool(action["CLEAN3F_STRESS"])
    s6570=bool(market_score>=65 and vix_score>=70)
    s7075=bool(market_score>=70 and vix_score>=75)

    base=read_one_row(args.base_row,"BASE diagnostic row")
    bdate=pd.Timestamp(base["Date"]).normalize()
    if bdate>target:
        raise ValueError("BASE diagnostic date cannot be after target.")
    staleness=(target-bdate).days
    if staleness>7:
        raise ValueError(f"BASE diagnostic stale by {staleness} days (>7).")
    if (clean_stress or s6570 or s7075) and bdate!=target:
        raise ValueError(
            "Stress/Sentinel observed but BASE diagnostic is not same-date. "
            "Immediate full GRRM refresh required."
        )

    ivy=read_one_row(args.ivy_state,"IVY state")
    signal_date=pd.Timestamp(ivy["SIGNAL_DATE"]).normalize()
    pass_slots=int(ivy["PASS_SLOTS"])
    ivy_invested=float(ivy["IVY_INVESTED"])
    if pass_slots not in range(5):
        raise ValueError("PASS_SLOTS must be 0..4.")
    if abs(ivy_invested-pass_slots/4)>1e-12:
        raise ValueError("IVY_INVESTED must equal PASS_SLOTS/4.")
    if signal_date>=target:
        raise ValueError("IVY SIGNAL_DATE must be strictly before target market date.")

    ivy_ret=""
    if "IVY_DAILY_RETURN" in ivy.index and pd.notna(ivy["IVY_DAILY_RETURN"]):
        ivy_ret=float(ivy["IVY_DAILY_RETURN"])

    meta_path=rawdir/"acquisition_metadata.json"
    available=""
    if meta_path.exists():
        meta=json.loads(meta_path.read_text(encoding="utf-8"))
        available=meta.get("acquired_utc","")

    note=(
        f"LIVE_SNAPSHOT;BASE_DATE={bdate.date()};BASE_STALE_DAYS={staleness};"
        f"VIX_DATE={vix_date.date()};BAA_DATE={baa_date.date()};AAA_DATE={aaa_date.date()};"
        f"PARITY={json.dumps(parity,sort_keys=True,separators=(',',':'))}"
    )

    row=pd.DataFrame([{
        "MARKET_DATE":target.date().isoformat(),
        "BASE_REGIME":int(float(base["BASE_REGIME"])),
        "VP":float(base["VP"]),
        "MSP":float(base["MSP"]),
        "CLEAN3F_VOTE":float(action["CLEAN3F_VOTE"]),
        "EQ_MA200_GAP":float(ma200_gap),
        "MSP_MARKET":float(market_score),
        "MSP_VOL":float(vix_score),
        "IVY_INVESTED":ivy_invested,
        "PASS_SLOTS":pass_slots,
        "SIGNAL_DATE":signal_date.date().isoformat(),
        "IVY_DAILY_RETURN":ivy_ret,
        "SOURCE_AVAILABLE_UTC":available,
        "SOURCE_NOTE":note,
    }])
    row.to_csv(args.out,index=False)

    if args.action_components_out:
        comp=pd.DataFrame([{
            "Date":target.date().isoformat(),
            "MSP_MARKET":float(market_score),
            "MSP_CREDIT_CONTROL":float(credit_score),
            "MSP_VOL":float(vix_score),
            "EQ_MA200_GAP":float(ma200_gap),
            "CLEAN3F_MSP":float(action["CLEAN3F_MSP"]),
            "CLEAN3F_MSP_D20":action["CLEAN3F_MSP_D20"],
            "CLEAN3F_VOTE":float(action["CLEAN3F_VOTE"]),
            "CLEAN3F_STRESS":bool(action["CLEAN3F_STRESS"]),
            "VIX_DATE":vix_date.date().isoformat(),
            "BAA_DATE":baa_date.date().isoformat(),
            "AAA_DATE":aaa_date.date().isoformat(),
        }])
        comp.to_csv(args.action_components_out,index=False)

    if not args.dry_run:
        kernel.save_seed(args.updated_seed_out,target.date().isoformat())
    else:
        Path(args.updated_seed_out).write_text(
            json.dumps({"dry_run":True,"operational_seed_not_mutated":True},indent=2),
            encoding="utf-8"
        )

    print(row.to_string(index=False))
    print("CLEAN3F internal:",json.dumps(action,indent=2))
    print("Sentinel 65/70:",s6570,"Sentinel 70/75:",s7075)

if __name__=="__main__":
    main()
