
"""
IVY11_GRRM_V1-HI — BASE V3 Live Diagnostic Refresher

Creates the same-date BASE diagnostic state from frozen V3 rules.

Important implementation detail:
The frozen MSP_D20 is a 20 *generic business-day* difference. Therefore the
refresher advances the BASE state on every Mon-Fri business-day between the last
committed BASE state and the requested target. Market holidays are represented
as internal calendar-bridge rows using as-of source values. Only the requested
target row is handed to the shadow snapshot.

This preserves the V3 state-machine calendar semantics without giving BASE any
live-capital authority.
"""
from __future__ import annotations
import argparse, importlib.util, sys, json
from pathlib import Path
import pandas as pd
import numpy as np

ANCHOR_DATE=pd.Timestamp("2026-10-02")

# Fixed before first online source-parity run. Units: normalized score points.
PARITY_TOLERANCE={
    "N_NFCI":1.0,
    "N_T10Y3M":1.0,
    "N_SAHM":1.5,
    "N_CAPE":2.0,
    "N_CREDIT_GAP":2.5,
    "N_DSR_DEV":2.5,
}

def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

def next_wednesday_after_week(d):
    d=pd.Timestamp(d)
    x=d+pd.Timedelta(days=1)
    return x+pd.Timedelta(days=(2-x.weekday())%7)

def quarterly_end(period):
    s=str(period).upper()
    if "Q" not in s: raise ValueError(f"Invalid quarterly period {period}")
    y=int(s[:4]); q=int(s.split("Q")[1])
    return pd.Timestamp(y,3*q,1)+pd.offsets.MonthEnd(0)

def stamp_available(raw,kind):
    x=raw.copy()
    if kind=="DAILY":
        x["obs_date"]=pd.to_datetime(x["Date"])
        x["available_date"]=x["obs_date"]
    elif kind=="NFCI":
        x["obs_date"]=pd.to_datetime(x["Date"])
        x["available_date"]=x["obs_date"].map(next_wednesday_after_week)
    elif kind=="MONTHLY35":
        x["obs_date"]=pd.to_datetime(x["Date"])
        x["available_date"]=x["obs_date"]+pd.Timedelta(days=35)
    elif kind=="QUARTERLY120":
        x["obs_date"]=x["Period"].map(quarterly_end)
        x["available_date"]=x["obs_date"]+pd.Timedelta(days=120)
    else:
        raise ValueError(kind)
    x["value"]=pd.to_numeric(x["value"],errors="coerce")
    return x.dropna(subset=["obs_date","available_date","value"]).sort_values("available_date")

def load_diag_sources(rawdir):
    r=Path(rawdir)
    return {
        "NFCI":stamp_available(pd.read_csv(r/"NFCI.csv"),"NFCI"),
        "T10Y3M":stamp_available(pd.read_csv(r/"T10Y3M.csv"),"DAILY"),
        "SAHM":stamp_available(pd.read_csv(r/"SAHMREALTIME.csv"),"MONTHLY35"),
        "CAPE":stamp_available(pd.read_csv(r/"CAPE_monthly.csv"),"MONTHLY35"),
        "CREDIT_GAP":stamp_available(pd.read_csv(r/"BIS_CREDIT_GAP.csv"),"QUARTERLY120"),
        "DSR":stamp_available(pd.read_csv(r/"BIS_DSR.csv"),"QUARTERLY120"),
    }

def asof_daily(z,target):
    z=z[z.available_date<=target].copy()
    if z.empty: return pd.Series(dtype=float)
    lo=z.available_date.min().normalize()
    cal=pd.bdate_range(lo,target)
    left=pd.DataFrame({"Date":cal})
    q=z[["available_date","value"]].sort_values("available_date")
    return pd.merge_asof(
        left,q,left_on="Date",right_on="available_date",direction="backward"
    ).set_index("Date")["value"]

def pct_current(s):
    q=pd.to_numeric(s,errors="coerce").dropna()
    if q.empty: return np.nan
    x=float(q.iloc[-1]); a=q.to_numpy(float)
    return float(100.0*(np.sum(a<=x)-0.5)/len(a))

def component_scores_from_sources(src,target):
    ser={k:asof_daily(v,target) for k,v in src.items()}
    if any(v.empty for v in ser.values()):
        bad=[k for k,v in ser.items() if v.empty]
        raise RuntimeError(f"Diagnostic sources unavailable by {target.date()}: {bad}")

    out={}
    out["N_NFCI"]=pct_current(ser["NFCI"])
    out["N_T10Y3M"]=100.0-pct_current(ser["T10Y3M"])
    out["N_SAHM"]=pct_current(ser["SAHM"])
    out["N_CAPE"]=pct_current(ser["CAPE"])
    out["N_CREDIT_GAP"]=pct_current(ser["CREDIT_GAP"])

    dsr=ser["DSR"]
    dev=dsr-dsr.expanding(min_periods=20).median()
    out["DSR_DEV"]=float(dev.iloc[-1]) if pd.notna(dev.iloc[-1]) else np.nan
    out["N_DSR_DEV"]=pct_current(dev)

    out["RAW_NFCI"]=float(ser["NFCI"].iloc[-1])
    out["RAW_T10Y3M"]=float(ser["T10Y3M"].iloc[-1])
    out["RAW_SAHM"]=float(ser["SAHM"].iloc[-1])
    out["RAW_CAPE"]=float(ser["CAPE"].iloc[-1])
    out["RAW_CREDIT_GAP"]=float(ser["CREDIT_GAP"].iloc[-1])
    out["RAW_DSR"]=float(ser["DSR"].iloc[-1])

    out["VP_VALUATION"]=out["N_CAPE"]
    out["VP_CURVE"]=out["N_T10Y3M"]
    out["VP_CREDITCYCLE"]=float(np.nanmean([out["N_CREDIT_GAP"],out["N_DSR_DEV"]]))
    out["MACRO_CONFIRM"]=out["N_SAHM"]
    return out

def native_asof_score(gu,df,col,target,high=True):
    # GU helper already restricts source observations to <= target.
    return gu.native_current_score(df,col,target,high)

def build_action_context(gu,action_anchor,action_rawdir,final_target):
    anchor=pd.read_csv(action_anchor,parse_dates=["Date"]).sort_values("Date")
    spy=pd.read_csv(Path(action_rawdir)/"SPY_recent.csv",parse_dates=["Date"])
    eq,_=gu.build_equity_continuation(anchor,spy,final_target)
    return {
        "anchor":anchor,
        "eq":eq,
        "vix":pd.read_csv(Path(action_rawdir)/"VIXCLS.csv"),
        "baa":pd.read_csv(Path(action_rawdir)/"BAA10Y.csv"),
        "aaa":pd.read_csv(Path(action_rawdir)/"AAA10Y.csv"),
    }

def action_scores_for_day(gu,ctx,day):
    eq=ctx["eq"].loc[:day]
    market,ma200,_=gu.market_score_from_equity(eq,day)
    vol,vdate,_=native_asof_score(gu,ctx["vix"],"VIXCLS",day,True)
    bscore,bdate,_=native_asof_score(gu,ctx["baa"],"BAA10Y",day,True)
    ascore,adate,_=native_asof_score(gu,ctx["aaa"],"AAA10Y",day,True)
    return {
        "MSP_MARKET":float(market),
        "MSP_CREDIT_CONTROL":float(np.mean([bscore,ascore])),
        "MSP_VOL":float(vol),
        "EQ_MA200_GAP":float(ma200),
        "VIX_DATE":pd.Timestamp(vdate),
        "BAA_DATE":pd.Timestamp(bdate),
        "AAA_DATE":pd.Timestamp(adate),
    }

def anchor_parity(anchor,src):
    a=pd.read_csv(anchor,parse_dates=["Date"]).set_index("Date").sort_index()
    frozen=a.loc[ANCHOR_DATE]
    current=component_scores_from_sources(src,ANCHOR_DATE)
    rows=[]; ok=True
    for c,tol in PARITY_TOLERANCE.items():
        diff=abs(float(current[c])-float(frozen[c]))
        passed=bool(diff<=tol); ok &= passed
        rows.append({
            "component":c,"frozen":float(frozen[c]),"recomputed":float(current[c]),
            "abs_diff":diff,"tolerance":tol,"pass":passed,
        })
    return pd.DataFrame(rows),ok

def frozen_components(anchor,target):
    a=pd.read_csv(anchor,parse_dates=["Date"]).set_index("Date")
    r=a.loc[target]
    slow={
        "N_NFCI":float(r.N_NFCI),"N_T10Y3M":float(r.N_T10Y3M),
        "N_SAHM":float(r.N_SAHM),"N_CAPE":float(r.N_CAPE),
        "N_CREDIT_GAP":float(r.N_CREDIT_GAP),"DSR_DEV":float(r.DSR_DEV),
        "N_DSR_DEV":float(r.N_DSR_DEV),"RAW_NFCI":float(r.NFCI),
        "RAW_T10Y3M":float(r.T10Y3M),"RAW_SAHM":float(r.SAHM),
        "RAW_CAPE":float(r.CAPE),"RAW_CREDIT_GAP":float(r.CREDIT_GAP),
        "RAW_DSR":float(r.DSR),"VP_VALUATION":float(r.VP_VALUATION),
        "VP_CURVE":float(r.VP_CURVE),"VP_CREDITCYCLE":float(r.VP_CREDITCYCLE),
        "MACRO_CONFIRM":float(r.MACRO_CONFIRM),
    }
    action={
        "MSP_MARKET":float(r.MSP_MARKET),
        "MSP_CREDIT_CONTROL":float(r.MSP_CREDIT_CONTROL),
        "MSP_VOL":float(r.MSP_VOL),
        "EQ_MA200_GAP":np.nan,
        "VIX_DATE":target,"BAA_DATE":target,"AAA_DATE":target,
    }
    return slow,action

def initial_msp_history(anchor,ledger=None):
    a=pd.read_csv(anchor,parse_dates=["Date"]).set_index("Date").sort_index()
    h={pd.Timestamp(d):float(v) for d,v in a["MSP"].dropna().items()}
    if ledger and Path(ledger).exists() and Path(ledger).stat().st_size>0:
        x=pd.read_csv(ledger,parse_dates=["Date"]).dropna(subset=["Date","MSP"])
        for _,r in x.iterrows():
            h[pd.Timestamp(r.Date).normalize()]=float(r.MSP)
    return h,a

def lag_msp_exact(day,history,anchor):
    lag=(day-pd.offsets.BDay(20)).normalize()
    if lag in history:
        return float(history[lag]),lag,"HISTORY"

    # Historical bridge reconstruction: if the lag date was omitted from the exported
    # anchor, V3's own future MSP_D20 observation identifies the exact hidden lag MSP.
    future=(lag+pd.offsets.BDay(20)).normalize()
    if future in anchor.index and pd.notna(anchor.loc[future,"MSP_D20"]):
        val=float(anchor.loc[future,"MSP"]-anchor.loc[future,"MSP_D20"])
        history[lag]=val
        return val,lag,"FROZEN_D20_BRIDGE"

    raise RuntimeError(f"Missing exact 20-business-day MSP lag {lag.date()}.")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--base-kernel",required=True)
    ap.add_argument("--base-state-seed",required=True)
    ap.add_argument("--component-anchor",required=True)
    ap.add_argument("--action-producer-module",required=True)
    ap.add_argument("--action-anchor",required=True)
    ap.add_argument("--action-rawdir",required=True)
    ap.add_argument("--diagnostic-rawdir",required=True)
    ap.add_argument("--target-date",required=True)
    ap.add_argument("--ledger")
    ap.add_argument("--out",required=True)
    ap.add_argument("--components-out",required=True)
    ap.add_argument("--parity-out",required=True)
    ap.add_argument("--updated-state-seed-out",required=True)
    ap.add_argument("--offline-anchor-parity",action="store_true")
    args=ap.parse_args()

    target=pd.Timestamp(args.target_date).normalize()
    gu=load_module(args.action_producer_module,"ivy_action_producer_for_base")
    bk=load_module(args.base_kernel,"ivy_base_kernel_live")

    seed_info=json.loads(Path(args.base_state_seed).read_text(encoding="utf-8"))
    seed_date=pd.Timestamp(seed_info["anchor_date"]).normalize()
    kernel=bk.BaseV3LiveKernel.from_seed_file(args.base_state_seed)

    history,anchor=initial_msp_history(args.component_anchor,args.ledger)

    if args.offline_anchor_parity:
        # Exact source-independent assembly test of a frozen historical target.
        slow,action=frozen_components(args.component_anchor,target)
        parity=pd.DataFrame([{
            "component":"OFFLINE_FROZEN_COMPONENT_MODE","frozen":np.nan,
            "recomputed":np.nan,"abs_diff":0.0,"tolerance":0.0,"pass":True
        }])
        parity.to_csv(args.parity_out,index=False)
        path=[target]
    else:
        if target<=seed_date:
            raise ValueError("BASE live target must be after state-seed anchor.")
        src=load_diag_sources(args.diagnostic_rawdir)
        parity,ok=anchor_parity(args.component_anchor,src)
        parity.to_csv(args.parity_out,index=False)
        if not ok:
            raise RuntimeError(
                "BASE diagnostic source-history parity failed. "
                "Do not silently accept revised current history."
            )
        ctx=build_action_context(gu,args.action_anchor,args.action_rawdir,target)
        path=list(pd.bdate_range(seed_date+pd.offsets.BDay(1),target))
        if not path or path[-1]!=target:
            raise ValueError("Target must be a Mon-Fri business date.")

    rows=[]
    for day in path:
        if args.offline_anchor_parity:
            slow,action=frozen_components(args.component_anchor,day)
        else:
            slow=component_scores_from_sources(src,day)
            action=action_scores_for_day(gu,ctx,day)

        msp=float(np.nanmean([
            action["MSP_MARKET"],action["MSP_CREDIT_CONTROL"],
            slow["N_NFCI"],action["MSP_VOL"]
        ]))
        lag_val,lag_date,lag_source=lag_msp_exact(day,history,anchor)
        d20=float(msp-lag_val)

        z=kernel.update(
            action["MSP_MARKET"],action["MSP_CREDIT_CONTROL"],slow["N_NFCI"],action["MSP_VOL"],
            slow["VP_VALUATION"],slow["VP_CURVE"],slow["VP_CREDITCYCLE"],slow["MACRO_CONFIRM"],
            d20
        )
        history[day]=msp

        rows.append({
            "RUN_TYPE":"TARGET" if day==target else "CALENDAR_BRIDGE",
            "Date":day.date().isoformat(),
            **action,**slow,
            "MSP":msp,"MSP_D20":d20,
            "MSP_D20_LAG_DATE":lag_date.date().isoformat(),
            "MSP_D20_LAG_SOURCE":lag_source,
            "VP":z["VP"],"BASE_REGIME":z["BASE_REGIME"],
            "FAST_TRACK":z["FAST_TRACK"],"RECOVERY":z["RECOVERY"],
        })

    comp=pd.DataFrame(rows)
    comp.to_csv(args.components_out,index=False)
    final=comp.iloc[-1]

    pd.DataFrame([{
        "Date":target.date().isoformat(),
        "BASE_REGIME":int(final.BASE_REGIME),
        "VP":float(final.VP),
        "MSP":float(final.MSP),
        "MACRO_CONFIRM":float(final.MACRO_CONFIRM),
        "SOURCE_NOTE":(
            f"BASE_V3_LIVE;BRIDGE_ROWS={max(0,len(comp)-1)};"
            f"D20_LAG={final.MSP_D20_LAG_DATE};"
            f"D20_SOURCE={final.MSP_D20_LAG_SOURCE};"
            f"PARITY={'OFFLINE_QA' if args.offline_anchor_parity else 'PASS'}"
        ),
    }]).to_csv(args.out,index=False)

    if args.offline_anchor_parity:
        Path(args.updated_state_seed_out).write_text(
            json.dumps({"offline_anchor_parity":True,"state_not_mutated":True},indent=2),
            encoding="utf-8"
        )
    else:
        kernel.save_seed(args.updated_state_seed_out,target.date().isoformat())

    print(pd.DataFrame([{
        "Date":target.date().isoformat(),"Regime":int(final.BASE_REGIME),
        "VP":float(final.VP),"MSP":float(final.MSP),
        "MSP_D20":float(final.MSP_D20),
        "bridge_rows":max(0,len(comp)-1)
    }]).to_string(index=False))
    print("Source-history parity:",
          "OFFLINE_QA" if args.offline_anchor_parity else "PASS")

if __name__=="__main__":
    main()
