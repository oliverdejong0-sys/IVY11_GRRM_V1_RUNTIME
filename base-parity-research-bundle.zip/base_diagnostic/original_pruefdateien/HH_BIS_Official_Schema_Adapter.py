#!/usr/bin/env python3
"""Read-only BIS SDMX schema adapter, separate from byte-preserved original HH.

Strict selection from official BIS csvfile/sdmx-csv-1.0.0 dimensions.
No modification of the BASE V3 scoring or the original HI refresher.
"""
from __future__ import annotations
import io
import re
import pandas as pd

SCHEMAS = {
    "Q.US.P.A.C": {
        "FREQ": "Q", "BORROWERS_CTY": "US", "TC_BORROWERS": "P",
        "TC_LENDERS": "A", "CG_DTYPE": "C",
    },
    "Q.US.P": {
        "FREQ": "Q", "BORROWERS_CTY": "US", "DSR_BORROWERS": "P",
    }
}

def parse_bis_csv(raw: bytes, key: str) -> pd.DataFrame:
    """Parse full BIS historical data. Fail-closed on wrong dimensions/duplicates."""
    if key not in SCHEMAS:
        raise ValueError(f"Unsupported BIS frozen model series: {key}")
    if not raw or len(raw) > 20_000_000:
        raise ValueError("Invalid BIS response length")
    df = pd.read_csv(io.BytesIO(raw), low_memory=False, dtype=str)
    required = set(SCHEMAS[key]) | {"TIME_PERIOD", "OBS_VALUE"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"BIS {key}: mandatory dimensions missing: {missing}")
    match = pd.Series(True, index=df.index)
    for col, code in SCHEMAS[key].items():
        actual = df[col].fillna("").str.strip().str.split(":", n=1).str[0].str.strip()
        match &= actual.eq(code)
    rows = df.loc[match, ["TIME_PERIOD", "OBS_VALUE"]].copy()
    if rows.empty:
        raise ValueError(f"BIS {key}: no rows match exact model dimensions {SCHEMAS[key]}")
    if not rows["TIME_PERIOD"].str.fullmatch(r"\d{4}-Q[1-4]").all():
        raise ValueError(f"BIS {key}: invalid quarter format")
    if rows["TIME_PERIOD"].duplicated().any():
        raise ValueError(f"BIS {key}: duplicate quarters")
    values = pd.to_numeric(rows["OBS_VALUE"], errors="coerce")
    if values.isna().any():
        raise ValueError(f"BIS {key}: missing or invalid OBS_VALUE")
    if len(rows) < 40:
        raise ValueError(f"BIS {key}: only {len(rows)} quarterly observations")
    if rows["TIME_PERIOD"].max() < "2026-Q1":
        raise ValueError(f"BIS {key}: history ends before frozen coverage validation period")
    result = pd.DataFrame({
        "Period": rows["TIME_PERIOD"].to_numpy(),
        "value": values.to_numpy(dtype=float),
    }).sort_values("Period").reset_index(drop=True)
    return result
