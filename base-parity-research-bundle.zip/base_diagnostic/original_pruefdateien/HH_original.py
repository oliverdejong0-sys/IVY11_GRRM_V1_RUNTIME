
"""
IVY11_GRRM_V1-HH — BASE Diagnostic Source Acquirer

Downloads the slow/diagnostic sources used by frozen BASE V3:
- NFCI (FRED/Chicago Fed)
- T10Y3M (FRED)
- SAHMREALTIME (FRED)
- Shiller CAPE monthly data
- BIS US credit-to-GDP gap Q.US.P.A.C
- BIS US private non-financial DSR Q.US.P

It does not calculate a regime and has no capital authority.

Primary BIS path uses the official BIS SDMX REST API; official bulk ZIP files are
kept as a fallback. All downloaded bytes are hashed and metadata are archived.
"""
from __future__ import annotations
import argparse, io, json, hashlib, zipfile, datetime as dt, re
from pathlib import Path
import pandas as pd
import numpy as np

UA="IVY11_GRRM_V1 shadow research; noncommercial; contact via interactive user"

def session():
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    s=requests.Session()
    retry=Retry(
        total=5,connect=5,read=5,backoff_factor=2,
        status_forcelist=[429,500,502,503,504],
        allowed_methods=["GET"]
    )
    s.mount("https://",HTTPAdapter(max_retries=retry))
    return s

def sha(b): return hashlib.sha256(b).hexdigest()

def fred(series_id,s):
    urls=[
        ("FRED",f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={series_id}"),
        ("ALFRED",f"https://alfred.stlouisfed.org/graph/alfredgraph.csv?id={series_id}")
    ]
    errs=[]
    for source,u in urls:
        try:
            r=s.get(u,headers={"User-Agent":UA},timeout=(20,180))
            r.raise_for_status()
            raw=r.content
            x=pd.read_csv(io.BytesIO(raw))
            d=x.columns[0]
            v=[c for c in x.columns if c!=d][0]
            z=pd.DataFrame({
                "Date":pd.to_datetime(x[d],errors="coerce"),
                "value":pd.to_numeric(x[v],errors="coerce")
            }).dropna().sort_values("Date").drop_duplicates("Date")
            if z.empty: raise ValueError("empty normalized series")
            return z,source,raw
        except Exception as e:
            errs.append(f"{source}:{e!r}")
    raise RuntimeError(f"{series_id} failed: {errs}")

def parse_bis_csv(raw,key):
    x=pd.read_csv(io.BytesIO(raw),low_memory=False)
    if "TIME_PERIOD" not in x.columns or "OBS_VALUE" not in x.columns:
        raise ValueError("BIS CSV missing TIME_PERIOD/OBS_VALUE.")

    # Exact series-key field if available.
    key_cols=[c for c in x.columns if c.upper() in {"KEY","SERIES_KEY","SERIES","TIME_SERIES_KEY"}]
    q=None
    for c in key_cols:
        m=x[c].astype(str).str.strip().eq(key)
        if m.any():
            q=x[m].copy(); break

    # Dimension-level fallback for known frozen series.
    if q is None:
        if key=="Q.US.P.A.C":
            aliases={
                "FREQ":"Q",
                "BORROWERS_CTY":"US",
                "BORROWERS_COUNTRY":"US",
                "REF_AREA":"US",
                "BORROWERS_SECTOR":"P",
                "LENDERS_SECTOR":"A",
                "LENDING_SECTOR":"A",
                "CREDIT_GAP_TYPE":"C",
                "CREDIT_GAP_DATA_TYPE":"C",
            }
            m=pd.Series(True,index=x.index)
            used=0
            # We need country, borrowing sector, lending sector and gap type.
            for candidates,val in [
                (["FREQ"],"Q"),
                (["BORROWERS_CTY","BORROWERS_COUNTRY","REF_AREA"],"US"),
                (["BORROWERS_SECTOR","BORROWING_SECTOR"],"P"),
                (["LENDERS_SECTOR","LENDING_SECTOR"],"A"),
                (["CREDIT_GAP_TYPE","CREDIT_GAP_DATA_TYPE","CREDIT_GAP"],"C"),
            ]:
                col=next((c for c in candidates if c in x.columns),None)
                if col is not None:
                    m &= x[col].astype(str).str.split(":").str[0].str.strip().eq(val)
                    used+=1
            if used>=5 and m.any():
                q=x[m].copy()

        elif key=="Q.US.P":
            m=pd.Series(True,index=x.index); used=0
            for candidates,val in [
                (["FREQ"],"Q"),
                (["BORROWERS_CTY","BORROWERS_COUNTRY","REF_AREA"],"US"),
                (["BORROWERS","BORROWERS_SECTOR","BORROWING_SECTOR"],"P"),
            ]:
                col=next((c for c in candidates if c in x.columns),None)
                if col is not None:
                    m &= x[col].astype(str).str.split(":").str[0].str.strip().eq(val)
                    used+=1
            if used>=3 and m.any():
                q=x[m].copy()

    if q is None or q.empty:
        raise ValueError(f"Could not identify BIS series {key} from columns {list(x.columns)}")

    z=pd.DataFrame({
        "Period":q["TIME_PERIOD"].astype(str),
        "value":pd.to_numeric(q["OBS_VALUE"],errors="coerce")
    }).dropna().drop_duplicates("Period").sort_values("Period")
    if z.empty: raise ValueError(f"BIS {key} has no observations.")
    return z

def bis_series(dataflow,key,s):
    # Official SDMX API primary.
    api=f"https://stats.bis.org/api/v2/data/dataflow/BIS/{dataflow}/1.0/{key}?format=csvfile"
    try:
        r=s.get(api,headers={"User-Agent":UA,"Accept":"text/csv"},timeout=(20,180))
        r.raise_for_status()
        raw=r.content
        z=parse_bis_csv(raw,key)
        return z,"BIS_SDMX_API",raw
    except Exception as api_err:
        # Official static bulk fallback.
        bulk=f"https://data.bis.org/static/bulk/{dataflow}_csv_flat.zip"
        r=s.get(bulk,headers={"User-Agent":UA},timeout=(20,240))
        r.raise_for_status()
        zipraw=r.content
        with zipfile.ZipFile(io.BytesIO(zipraw)) as zz:
            csvs=[n for n in zz.namelist() if n.lower().endswith(".csv")]
            if not csvs: raise RuntimeError(f"{dataflow}: ZIP has no CSV.") from api_err
            last=None
            for n in csvs:
                try:
                    raw=zz.read(n)
                    z=parse_bis_csv(raw,key)
                    return z,"BIS_BULK_ZIP",zipraw
                except Exception as e:
                    last=e
            raise RuntimeError(f"{dataflow}: bulk parse failed: {last!r}") from api_err

def shiller_cape(s):
    u="https://www.econ.yale.edu/~shiller/data/ie_data.xls"
    r=s.get(u,headers={"User-Agent":UA},timeout=(20,180))
    r.raise_for_status()
    raw=r.content

    # Typical Shiller workbook has a "Data" sheet with explanatory rows above headers.
    last=None
    for skip in range(5,10):
        try:
            x=pd.read_excel(io.BytesIO(raw),sheet_name="Data",skiprows=skip)
            cols={str(c).strip().upper():c for c in x.columns}
            cape_col=next((orig for up,orig in cols.items() if "CAPE" in up),None)
            date_col=next((orig for up,orig in cols.items() if up=="DATE" or up.startswith("DATE.")),None)
            if cape_col is None or date_col is None:
                continue
            vals=pd.to_numeric(x[cape_col],errors="coerce")
            dates=[]
            for v in x[date_col]:
                if pd.isna(v):
                    dates.append(pd.NaT); continue
                s0=str(v).strip()
                # Shiller date is usually YYYY.MM, e.g. 2026.09.
                try:
                    num=float(s0)
                    y=int(num)
                    frac=int(round((num-y)*100))
                    m=max(1,min(12,frac))
                    dates.append(pd.Timestamp(y,m,1)+pd.offsets.MonthEnd(0))
                except Exception:
                    dates.append(pd.to_datetime(s0,errors="coerce")+pd.offsets.MonthEnd(0))
            z=pd.DataFrame({"Date":dates,"value":vals}).dropna().sort_values("Date").drop_duplicates("Date")
            if len(z)>1000:
                return z,"SHILLER_YALE",raw
        except Exception as e:
            last=e
    raise RuntimeError(f"Could not parse Shiller CAPE workbook: {last!r}")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--outdir",required=True)
    args=ap.parse_args()
    out=Path(args.outdir); out.mkdir(parents=True,exist_ok=True)
    s=session()
    meta={
        "acquired_utc":dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "sources":{}
    }

    for sid in ["NFCI","T10Y3M","SAHMREALTIME"]:
        z,source,raw=fred(sid,s)
        z.to_csv(out/f"{sid}.csv",index=False)
        meta["sources"][sid]={
            "provider":source,"sha256":sha(raw),"rows":len(z),
            "first":str(z.Date.min().date()),"last":str(z.Date.max().date())
        }

    z,source,raw=shiller_cape(s)
    z.to_csv(out/"CAPE_monthly.csv",index=False)
    meta["sources"]["CAPE"]={
        "provider":source,"sha256":sha(raw),"rows":len(z),
        "first":str(z.Date.min().date()),"last":str(z.Date.max().date())
    }

    for flow,key,name in [
        ("WS_CREDIT_GAP","Q.US.P.A.C","BIS_CREDIT_GAP"),
        ("WS_DSR","Q.US.P","BIS_DSR"),
    ]:
        z,source,raw=bis_series(flow,key,s)
        z.to_csv(out/f"{name}.csv",index=False)
        meta["sources"][name]={
            "provider":source,"series_key":key,"sha256":sha(raw),"rows":len(z),
            "first":str(z.Period.min()),"last":str(z.Period.max())
        }

    (out/"BASE_diagnostic_acquisition_metadata.json").write_text(
        json.dumps(meta,indent=2),encoding="utf-8"
    )
    print(json.dumps(meta,indent=2))

if __name__=="__main__":
    main()
