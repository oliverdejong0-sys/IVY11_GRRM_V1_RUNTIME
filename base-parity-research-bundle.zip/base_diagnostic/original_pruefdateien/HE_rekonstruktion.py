"""
IVY11 BASE V3 — RECONSTRUCTED DIAGNOSTIC KERNEL (RESEARCH ONLY)

Not the original IVY11_GRRM_V1-HE_BASE_Live_Diagnostic_Kernel.py.
The original source and HF seed are unavailable. Reconstructed independently
from canonical historical HG component anchor, matching historical BASE_REGIME,
VP and MSP. Non-financial diagnostic only.

Do not publish / trade / advance production seeds until all online source
parity gates pass. No regime-dependent cash control.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np


class BaseV3LiveKernel:
    def __init__(self, prev_regime: int = 5, fallrun: int = 0,
                 anchor_date: str | None = None):
        self.prev_regime = int(prev_regime)
        self.fallrun = int(fallrun)
        self.anchor_date = anchor_date
        if self.prev_regime not in range(1, 8) or self.fallrun < 0:
            raise ValueError("Invalid BASE V3 state")

    @classmethod
    def from_seed_file(cls, path):
        state = json.loads(Path(path).read_text(encoding="utf-8"))
        if state.get("reconstruction_status") != "RESEARCH_ONLY_NONORIGINAL":
            raise ValueError("Expected explicitly labeled reconstructed BASE seed")
        if state.get("kernel") != "BASE_V3_RECONSTRUCTED":
            raise ValueError("Kernel marker mismatch")
        return cls(state["prev_regime"], state["fallrun"], state["anchor_date"])

    def update(self, market, credit, nfci, vol, valuation, curve,
               creditcycle, macro_confirm, msp_d20):
        vals = np.array([valuation, curve, creditcycle], dtype=float)
        risk = np.array([market, credit, nfci, vol], dtype=float)
        if not np.isfinite(vals).any() or not np.isfinite(risk).any():
            raise ValueError("BASE components entirely missing")
        vp = float(np.nanmean(vals))
        msp = float(np.nanmean(risk))
        market = float(market)
        credit = float(credit)
        vol = float(vol)
        msp_d20 = float(msp_d20)
        if not np.isfinite(msp_d20):
            raise ValueError("Missing 20-generic-business-day MSP delta")

        # Exact historical-replay predicates, inferred from HG (9,287 rows).
        # Financial transitions below have NOT been separately forward-validated.
        fast_stress = bool(
            (msp >= 65.0) and (market >= 70.0)
            and ((vol >= 70.0) or (credit >= 70.0))
        )
        if fast_stress:
            baseline = 7 if msp >= 85.0 else 6
        elif vp >= 70.0 and msp < 65.0:
            baseline = 5
        elif vp >= 55.0 or (45.0 <= msp < 65.0):
            baseline = 4
        else:
            baseline = 3

        prev = self.prev_regime
        if prev == 7:
            self.fallrun = (self.fallrun + 1) if msp_d20 <= -3.0 else 0
            next_regime = 1 if self.fallrun >= 3 else 7
        elif prev == 1:
            if fast_stress and msp_d20 >= 3.5:
                next_regime = baseline
            elif msp < 65.0:
                next_regime = 2
            else:
                next_regime = 1
        elif prev == 2:
            if (fast_stress and msp_d20 >= 3.5) or msp < 45.0:
                next_regime = baseline
            else:
                next_regime = 2
        elif prev == 6 and msp < 65.0 and market < 70.0 and msp_d20 < 0.0:
            next_regime = 2
        else:
            next_regime = baseline

        if next_regime != 7:
            self.fallrun = 0
        self.prev_regime = int(next_regime)
        return {
            "VP": vp, "MSP": msp, "BASE_REGIME": next_regime,
            # Flags not present in HG; research diagnostic definitions only.
            "FAST_TRACK": fast_stress,
            "RECOVERY": (next_regime in (1, 2)),
        }

    def save_seed(self, path, date):
        # Explicitly preserve research marker; no production seed is overwritten.
        state = {
            "kernel": "BASE_V3_RECONSTRUCTED",
            "reconstruction_status": "RESEARCH_ONLY_NONORIGINAL",
            "anchor_date": str(date),
            "prev_regime": self.prev_regime,
            "fallrun": self.fallrun,
            "production_approved": False,
            "source": "Reconstructed from HG 1990-01-02..2026-10-02",
            "original_HE_HF_SHA256_verified": False,
        }
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n",
                     encoding="utf-8")
