#!/usr/bin/env python3
"""Deterministic read-only tests for narrow October 2026 source fixes."""
import importlib.util
import io
import json
import pathlib
import sys
import unittest
from unittest.mock import patch

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec)
    sys.modules[name]=obj
    spec.loader.exec_module(obj)
    return obj

b=load("bis_strict_test",ROOT/"original_pruefdateien/HH_BIS_Official_Schema_Adapter.py")
online=load("ivy_online_schema_test",ROOT/"IVY11_BASE_Online_Abnahme.py")

def csv_key(key, *, fmt="csvfile", wrong=False, duplicate=False, null=False):
    if key=="Q.US.P.A.C":
        dim={"FREQ":"Q","BORROWERS_CTY":"US","TC_BORROWERS":"P",
             "TC_LENDERS":"A","CG_DTYPE":"C"}
    else:
        dim={"FREQ":"Q","BORROWERS_CTY":"US","DSR_BORROWERS":"P"}
    if wrong:
        dim["BORROWERS_CTY"]="DE"
    years=[(1958+i//4, i%4+1) for i in range(274)] if key=="Q.US.P.A.C" else [(1999+i//4,i%4+1) for i in range(109)]
    rows=[{**dim,"TIME_PERIOD":f"{y:04d}-Q{q}","OBS_VALUE":str(i/3+10)} for i,(y,q) in enumerate(years)]
    if fmt=="sdmx-csv-1.0.0":
        for row in rows:row["DATAFLOW"]="BIS:WS_CREDIT_GAP(1.0)" if key=="Q.US.P.A.C" else "BIS:WS_DSR(1.0)"
    if duplicate:rows.append(rows[-1].copy())
    if null:rows[-1]["OBS_VALUE"]=""
    return pd.DataFrame(rows).to_csv(index=False).encode()

class Response:
    def __init__(self,obj):
        self.data=obj
        self.content=json.dumps(obj).encode()
    def raise_for_status(self):pass
    def json(self):return self.data

class FakeAPI:
    def __init__(self, rows):self.rows=rows
    def get(self,*args,**kwargs):
        return Response({"count":len(self.rows),"observations":self.rows})

class SourceSchemaSafety(unittest.TestCase):
    def test_bis_credit_csvfile(self):
        r=b.parse_bis_csv(csv_key("Q.US.P.A.C"),"Q.US.P.A.C")
        self.assertEqual(len(r),274)
        self.assertEqual(r.iloc[-1].Period,"2026-Q2") # synthetic coverage after frozen date

    def test_bis_dsr_csvfile(self):
        r=b.parse_bis_csv(csv_key("Q.US.P"),"Q.US.P")
        self.assertEqual(len(r),109)
        self.assertEqual(r.iloc[-1].Period,"2026-Q1")

    def test_bis_both_sdmx_formats(self):
        for key in ("Q.US.P.A.C","Q.US.P"):
            for fmt in ("csvfile","sdmx-csv-1.0.0"):
                with self.subTest(key=key,fmt=fmt):
                    r=b.parse_bis_csv(csv_key(key,fmt=fmt),key)
                    self.assertGreaterEqual(len(r),100)

    def test_wrong_country_rejected(self):
        for key in ("Q.US.P.A.C","Q.US.P"):
            with self.subTest(key=key):
                with self.assertRaisesRegex(ValueError,"no rows match"):
                    b.parse_bis_csv(csv_key(key,wrong=True),key)

    def test_wrong_credit_gap_type_rejected(self):
        x=pd.read_csv(io.BytesIO(csv_key("Q.US.P.A.C")))
        x["CG_DTYPE"]="Z"
        with self.assertRaisesRegex(ValueError,"no rows match"):
            b.parse_bis_csv(x.to_csv(index=False).encode(),"Q.US.P.A.C")

    def test_wrong_lender_sector_rejected(self):
        x=pd.read_csv(io.BytesIO(csv_key("Q.US.P.A.C")))
        x["TC_LENDERS"]="P"
        with self.assertRaisesRegex(ValueError,"no rows match"):
            b.parse_bis_csv(x.to_csv(index=False).encode(),"Q.US.P.A.C")

    def test_duplicate_quarters_rejected(self):
        with self.assertRaisesRegex(ValueError,"duplicate quarters"):
            b.parse_bis_csv(csv_key("Q.US.P.A.C",duplicate=True),"Q.US.P.A.C")

    def test_missing_observations_rejected(self):
        with self.assertRaisesRegex(ValueError,"missing or invalid"):
            b.parse_bis_csv(csv_key("Q.US.P",null=True),"Q.US.P")

    def test_missing_dimension_rejected(self):
        dat=pd.read_csv(io.BytesIO(csv_key("Q.US.P.A.C"))).drop(columns=["TC_LENDERS"])
        with self.assertRaisesRegex(ValueError,"mandatory dimensions missing"):
            b.parse_bis_csv(dat.to_csv(index=False).encode(),"Q.US.P.A.C")

    def test_misleading_key_absent_dimensions_rejected(self):
        dat=pd.DataFrame({"KEY":["Q.US.P.A.C"],"TIME_PERIOD":["2026-Q1"],"OBS_VALUE":[1.2]})
        with self.assertRaisesRegex(ValueError,"mandatory dimensions missing"):
            b.parse_bis_csv(dat.to_csv(index=False).encode(),"Q.US.P.A.C")

    def test_sahm_monthly_reference_date_accepted(self):
        days=pd.date_range("1959-01-01","2026-09-01",freq="MS")
        rows=[{"date":d.date().isoformat(),"value":str(i/100)} for i,d in enumerate(days)]
        logs=[]
        result=online.request_official_fred(FakeAPI(rows),"SAHMREALTIME","a"*32,logs)
        self.assertEqual(len(result),len(rows))
        self.assertEqual(str(result.Date.max().date()),"2026-09-01")
        self.assertEqual(logs[0]["frequency_policy"],"MONTHLY_REFERENCE_DATE")

    def test_sahm_missing_last_month_rejected(self):
        days=pd.date_range("1959-01-01","2026-08-01",freq="MS")
        rows=[{"date":d.date().isoformat(),"value":str(i/100)} for i,d in enumerate(days)]
        with self.assertRaisesRegex(RuntimeError,"no fallback"):
            online.request_official_fred(FakeAPI(rows),"SAHMREALTIME","a"*32,[])

    def test_daily_fred_still_requires_anchor(self):
        days=pd.date_range("1959-01-01","2026-09-30",freq="MS")
        rows=[{"date":d.date().isoformat(),"value":str(i/100)} for i,d in enumerate(days)]
        with self.assertRaisesRegex(RuntimeError,"no fallback"):
            online.request_official_fred(FakeAPI(rows),"VIXCLS","a"*32,[])

    def test_unapproved_key_rejected(self):
        with self.assertRaisesRegex(ValueError,"Unsupported"):
            b.parse_bis_csv(csv_key("Q.US.P"),"Q.EU.P")

if __name__=="__main__":
    unittest.main(verbosity=2)
